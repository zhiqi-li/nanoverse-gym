"""Exact retained native pair-contact service."""
import numpy as np


def unpack_contacts(buffers, body_pair, capacity):
    if buffers is None:
        raise RuntimeError("Native contact view is not initialized; missing contact evidence is not zero contact")
    arrays = [np.asarray(value.cpu() if hasattr(value, "cpu") else value) for value in buffers]
    impulses, points, normals, distances, counts, starts = arrays
    if counts.ndim != 2 or counts.shape != starts.shape or np.any(counts < 0) or np.any(starts < 0):
        raise ValueError("Malformed native pair-contact offsets")
    if int(counts.sum()) >= capacity:
        raise RuntimeError("Native contact buffer may be saturated; refusing incomplete impact evidence")
    records = []
    for shape, filter_index in np.ndindex(counts.shape):
        count, start = int(counts[shape, filter_index]), int(starts[shape, filter_index])
        if start + count > len(impulses):
            raise ValueError("Native contact range exceeds the supplied buffer")
        for index in range(start, start + count):
            impulse = float(np.asarray(impulses[index]).item())
            point, normal = points[index], normals[index]
            if not np.isfinite([impulse, *point, *normal, float(distances[index].item())]).all():
                raise ValueError("Non-finite native contact evidence")
            records.append({
                "body_pair": list(body_pair), "source_shape_index": shape, "filter_index": filter_index,
                "normal_impulse_ns": impulse, "impulse_world_ns": (normal * impulse).tolist(),
                "point_world_m": point.tolist(), "normal_world": normal.tolist(),
                "separation_m": float(distances[index].item()),
            })
    return records


def checked_targets(body_pair, target_paths):
    """Bind one logical wildcard group to its three exact current body paths."""
    import re

    if not isinstance(target_paths, list | tuple) or len(target_paths) != 3:
        raise ValueError("The retained sweep group requires exactly three current target paths")
    targets = tuple(target_paths)
    paths = (body_pair[0], *targets)
    if any(not isinstance(path, str) or not re.fullmatch(r"(?:/[A-Za-z_][A-Za-z0-9_]*)+", path)
           for path in paths):
        raise ValueError("Contact paths must be exact absolute actor paths without patterns")
    if len(set(targets)) != 3 or body_pair[0] in targets:
        raise ValueError("Contact targets must be distinct from each other and the source")
    parents = {path.rsplit("/", 1)[0] for path in targets}
    if len(parents) != 1 or body_pair[1] != next(iter(parents)) + "/.*":
        raise ValueError("Current targets do not exhaust the declared sibling actor group")
    return targets


def unpack_group_contacts(buffers, body_pair, capacity, sensor_paths, filter_paths):
    """Keep actual native filter indices and annotate their logical-group mapping."""
    if buffers is None:
        raise RuntimeError("Native contact view is not initialized; missing evidence is not zero contact")
    arrays = [np.asarray(value.cpu() if hasattr(value, "cpu") else value) for value in buffers]
    if len(arrays) != 6:
        raise ValueError("Expected the six original native contact buffers")
    impulses, points, normals, distances, counts, starts = arrays
    expected_shapes = [(capacity, 1), (capacity, 3), (capacity, 3), (capacity, 1), (1, 3), (1, 3)]
    if [array.shape for array in arrays] != expected_shapes:
        raise ValueError("Group contact buffer shapes differ from actual native capacity/source/filter counts")
    if counts.dtype.kind not in "iu" or starts.dtype.kind not in "iu":
        raise ValueError("Native contact counts and offsets must be integer arrays")
    if np.any(counts < 0) or np.any(starts < 0):
        raise ValueError("Malformed native pair-contact offsets")
    if int(counts.sum()) >= capacity:
        raise RuntimeError("Native contact buffer may be saturated; refusing incomplete impact evidence")
    occupied = set()
    for shape, filter_index in np.ndindex(counts.shape):
        start, count = int(starts[shape, filter_index]), int(counts[shape, filter_index])
        if start + count > capacity:
            raise ValueError("Native contact range exceeds the supplied buffer")
        indices = set(range(start, start + count))
        if occupied.intersection(indices):
            raise ValueError("Native contact ranges overlap across filters")
        occupied.update(indices)
    if tuple(sensor_paths) != (body_pair[0],):
        raise ValueError("Native source provenance differs from the logical group source")
    targets = checked_targets(body_pair, filter_paths)
    records = unpack_contacts(arrays, body_pair, capacity)
    for record in records:
        index = record["filter_index"]
        record["native_body_pair"] = [sensor_paths[record["source_shape_index"]], targets[index]]
        record["logical_filter_index"] = 0
    return records

class NativePairContacts:
    def __init__(self, body_a, body_b, name="task_pair_contact", capacity=64, *, target_paths=None, regions=None):
        import carb.settings
        from isaacsim.core.api.sensors import RigidContactView

        self.body_pair, self.capacity = (str(body_a), str(body_b)), capacity
        self.target_paths = checked_targets(self.body_pair, target_paths) if target_paths is not None else None
        if regions is not None and self.target_paths is None:
            raise ValueError("Event regions require exact current native target paths")
        self.regions = regions
        self.native_sensor_paths, self.native_filter_paths = None, None
        self.settings = carb.settings.get_settings()
        self.processing_disabled_before = self.settings.get("/physics/disableContactProcessing")
        # IsaacLab disables CPU contact processing by default. Its own contact
        # sensor enables this exact flag; the core RigidContactView does not.
        self.settings.set_bool("/physics/disableContactProcessing", False)
        self.view = RigidContactView(
            prim_paths_expr=str(body_a),
            filter_paths_expr=list(self.target_paths) if self.target_paths is not None else [str(body_b)],
            name=name,
            prepare_contact_sensors=False, disable_stablization=False, max_contact_count=capacity,
        )

    def initialize(self):
        self.settings.set_bool("/physics/disableContactProcessing", False)
        self.view.initialize()
        if self.target_paths is None:
            if self.view.num_shapes <= 0 or self.view.num_filters != 1:
                raise RuntimeError("Expected a nonempty source body and one explicit target-body contact filter")
            return
        if self.view.num_shapes != 1 or self.view.num_filters != len(self.target_paths):
            raise RuntimeError("Expected one native source and three exact native target filters")
        native = self.view._physics_view
        if native is None or native._backend is None:
            raise RuntimeError("Native group contact backend is absent")
        sensors, filters = tuple(native.sensor_paths), tuple(tuple(row) for row in native.filter_paths)
        if sensors != (self.body_pair[0],) or filters != (self.target_paths,):
            raise RuntimeError("Actual native sensor/filter paths differ from the declared current actors")
        self.native_sensor_paths, self.native_filter_paths = sensors, filters[0]
        if self.regions is not None:
            self.regions.initialize(self)

    def configuration(self):
        result = {
            "body_pair": list(self.body_pair), "source_shapes": int(self.view.num_shapes),
            "filters": int(self.view.num_filters), "capacity": self.capacity,
            "contact_processing_disabled_before": self.processing_disabled_before,
            "contact_processing_disabled_now": self.settings.get("/physics/disableContactProcessing"),
            "impulse_read_dt": 1.0,
        }
        if self.target_paths is not None:
            result.update(native_sensor_paths=list(self.native_sensor_paths),
                          native_filter_paths=list(self.native_filter_paths),
                          logical_groups=[{"body_pair": list(self.body_pair),
                                           "native_filter_indices": list(range(len(self.target_paths))),
                                           "target_paths": list(self.target_paths)}])
        if self.regions is not None:
            result["event_regions"] = self.regions.admission
        return result

    def begin_step(self):
        if self.regions is not None:
            self.regions.begin()

    def abort_step(self):
        if self.regions is not None:
            self.regions.abort()

    def close(self):
        if self.regions is not None:
            self.regions.close()

    def read(self):
        # SDK dt=1 returns the original impulse (N*s), not a scaled force.
        if self.target_paths is None:
            return unpack_contacts(self.view.get_contact_force_data(dt=1.0), self.body_pair, self.capacity)
        if self.native_sensor_paths is None or self.native_filter_paths is None:
            raise RuntimeError("Native current group provenance has not been initialized")
        if self.regions is not None:
            self.regions.before_read()
        contacts = unpack_group_contacts(self.view.get_contact_force_data(dt=1.0), self.body_pair, self.capacity,
                                         self.native_sensor_paths, self.native_filter_paths)
        return contacts if self.regions is None else self.regions.finish(contacts)
