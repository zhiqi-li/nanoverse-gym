"""Small task-owned extensions for demonstrated native object lifecycle gaps."""

from pxr import Usd, UsdGeom, UsdPhysics


def install_cpu_collider_cleanup(scene_manager):
    """Disable discarded compound shapes while preserving native CPU body views.

    Native CPU rigid/geometry deletion leaves child colliders enabled. Native
    Dynamic deletion removes the root; with nested bodies, that invalidates the
    live Tensor views. Retire those isolated assemblies in place, and retain
    native deletion for other supported resources. Keep native reset ownership.
    This helper is copied into the task package without an authoring dependency.
    """
    if scene_manager.device.type != "cpu" or scene_manager.use_fabric:
        return
    original_delete = scene_manager.delete_scene_object
    if getattr(original_delete, "_compound_collider_cleanup", False):
        return

    def delete_scene_object(obj):
        kind = obj.instance_config.get("physics", {}).get("type")
        if kind not in ("rigid", "geometry", "dynamic"):
            return original_delete(obj)
        prim = obj.prim
        stage, path = prim.GetStage(), prim.GetPath()
        # The initial native reload reuses its configured prim paths. Keep its
        # original deletion so retirement overrides cannot hide the new object.
        preserve_dynamic = kind == "dynamic" and not scene_manager.setup_scene and any(
            child.HasAPI(UsdPhysics.RigidBodyAPI)
            for child in Usd.PrimRange(prim, Usd.TraverseInstanceProxies())
        )
        if preserve_dynamic:
            # A retired assembly must not continue constraining another object.
            for child in Usd.PrimRange(prim, Usd.TraverseInstanceProxies()):
                if child.IsInstanceProxy() and child.HasAPI(UsdPhysics.CollisionAPI):
                    raise ValueError("Compound cleanup requires non-instanced collision shapes: " + str(path))
            # Joint prims can live outside either body subtree. Inspect incoming
            # relations too, so an external joint cannot retain a live coupling.
            for child in stage.Traverse(Usd.TraverseInstanceProxies()):
                if child.IsA(UsdPhysics.Joint):
                    joint = UsdPhysics.Joint(child)
                    targets = joint.GetBody0Rel().GetTargets() + joint.GetBody1Rel().GetTargets()
                    if ((child.GetPath().HasPrefix(path) or any(target.HasPrefix(path) for target in targets))
                            and any(target and not target.HasPrefix(path) for target in targets)):
                        raise ValueError("Dynamic retirement requires self-contained joint bodies: " + str(path))
            # Do not remove/deactivate rigid bodies or joints bound to live views.
            UsdGeom.Imageable(prim).MakeInvisible()
            result = None
        else:
            result = original_delete(obj)
        discarded = stage.GetPrimAtPath(path)
        if discarded:
            colliders = [child for child in Usd.PrimRange(discarded, Usd.TraverseInstanceProxies())
                         if child.HasAPI(UsdPhysics.CollisionAPI)]
            if any(child.IsInstanceProxy() for child in colliders):
                raise ValueError("Compound cleanup requires non-instanced collision shapes: " + str(path))
            for child in colliders:
                if not UsdPhysics.CollisionAPI(child).GetCollisionEnabledAttr().Set(False):
                    raise RuntimeError("Cannot disable discarded collision shape: " + str(child.GetPath()))
        return result

    delete_scene_object._compound_collider_cleanup = True
    scene_manager.delete_scene_object = delete_scene_object
