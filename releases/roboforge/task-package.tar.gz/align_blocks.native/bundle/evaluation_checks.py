"""Portable CPU contracts for an evaluation revision's actual native source."""

import ast
import math
from copy import deepcopy
from types import SimpleNamespace

import numpy as np
import yaml


def check(bundle, spec):
    config = yaml.safe_load((bundle / "task_config.yaml").read_text())
    tree = ast.parse((bundle / "task.py").read_text())
    task = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == spec["name"])
    tick = next(node for node in task.body if isinstance(node, ast.FunctionDef) and node.name == "sim_step")
    assignments = [node for node in ast.walk(tick) if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Attribute) and target.attr.endswith("_complete")
                           for target in node.targets)]
    if len(assignments) != 1:
        raise ValueError("Expected one native completion update")
    assignment = assignments[0]
    completion = assignment.targets[0].attr
    expression = assignment.value
    if not (isinstance(expression, ast.Call) and isinstance(expression.func, ast.Name)
            and expression.func.id == "bool" and len(expression.args) == 1
            and isinstance(expression.args[0], ast.Subscript)
            and isinstance(expression.args[0].slice, ast.Constant)
            and expression.args[0].slice.value == "success"):
        raise ValueError("Native completion must use the rubric's qualified success")
    report_name = expression.args[0].value.attr
    code = compile(ast.Module(body=[assignment], type_ignores=[]), str(bundle / "task.py"), "exec")
    owner = SimpleNamespace(held_seconds=0.0, dt=.004)
    rows = []
    for name, satisfied, success in (("pending_stability", True, False),
                                     ("qualified_success", True, True),
                                     ("disturbed_after_success", False, False)):
        setattr(owner, report_name, {"satisfied": satisfied, "success": success})
        exec(code, {"self": owner})
        rows.append({"name": name, "passed": getattr(owner, completion) is success,
                     "requirements": ["single_completion_hold"],
                     "evidence": {"rubric_success": success, "native_completion": getattr(owner, completion),
                                  "extra_native_hold_seconds": owner.held_seconds,
                                  "scope": "Actual native completion expression with constructed rubric receipts"}})
    if spec["name"] != "align_blocks":
        return rows

    definitions = [node for node in tree.body if getattr(node, "name", "") in
                   ("rotation_matrix", "row_metrics", "Rubric")]
    scope = {"np": np, "math": math}
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(bundle / "task.py"), "exec"), scope)
    declaration = __import__("json").loads((bundle / "native_task.json").read_text())
    layout = __import__("json").loads((bundle / declaration["layouts"][0]["path"]).read_text())
    initial = {item["label"]: {"position": item["default_pos"], "orientation": item["default_ori"],
                              "linear_velocity": [0, 0, 0], "angular_velocity": [0, 0, 0]}
               for items in layout["Rigid"].values() for item in items}
    pair = ["/tool", "/blocks/.*"]

    def frame(*, lift=0.0, pitch=0.0, held=False, dy=0.0, contacts=False):
        states = deepcopy(initial)
        tool = states["set_square"]
        tool["position"][2] += lift
        tool["orientation"] = [math.cos(pitch / 2), 0, math.sin(pitch / 2), 0]
        grasp = np.asarray(tool["position"]) + scope["rotation_matrix"](tool["orientation"]) @ np.asarray(
            config["rubric_metadata"]["set_square"]["grasp"]["center"])
        for name in ("block_0", "block_1", "block_2"):
            states[name]["position"][1] += dy
        return {"objects": states, "grippers": [[-1, -1, 1], grasp.tolist()],
                "gripper_gaps": [.088, .020 if held else .088], "all_joint_positions": np.zeros((2, 8)),
                "contact_body_pair": pair, "contacts": [
                    {"body_pair": pair, "normal_impulse_ns": .001, "normal_world": [0, 1, 0],
                     "point_world_m": states[name]["position"]}
                    for name in ("block_0", "block_1", "block_2")] if contacts else []}

    def evaluator():
        value = scope["Rubric"](spec, config["rubric_metadata"], 0, initial)
        value.step(frame(), .004)
        return value

    report = evaluator().step(frame(lift=.020, pitch=-.25, held=True), .004)
    rows.append({"name": "single_end_pickup", "passed": report["tool_pickup_recorded"],
                 "requirements": ["grasp_point_pickup"], "evidence": {
                     "origin_lift_m": report["tool_origin_lift_m"], "grasp_lift_m": report["grasp_lift_m"],
                     "pickup_credit": report["criteria"]["tool_acquired"]["value"]}})
    report = evaluator().step(frame(lift=.05, held=False), .004)
    rows.append({"name": "unheld_lift_denied", "passed": report["criteria"]["tool_acquired"]["value"] == 0,
                 "requirements": ["grasp_point_pickup"], "evidence": {"pickup_credit": report["criteria"]["tool_acquired"]["value"]}})
    value = evaluator()
    value.step(frame(held=True, contacts=True), .004)
    report = value.step(frame(held=True, contacts=True, dy=.020), .004)
    rows.append({"name": "push_before_pickup_completion", "passed":
                 report["criteria"]["indirect_pushes"]["value"] == 1 and not report["success"],
                 "requirements": ["independent_push_credit"], "evidence": {
                     "push_distances_m": report["push_distances_m"], "success": report["success"]}})
    value = evaluator()
    value.step(frame(held=True, contacts=True), .004)
    value.step(frame(dy=.06), .2)
    report = value.step(frame(held=True, contacts=True, dy=.06), .004)
    rows.append({"name": "unrelated_movement_denied", "passed": report["criteria"]["indirect_pushes"]["value"] == 0,
                 "requirements": ["contact_segment_provenance"], "evidence": {"push_distances_m": report["push_distances_m"]}})
    return rows
