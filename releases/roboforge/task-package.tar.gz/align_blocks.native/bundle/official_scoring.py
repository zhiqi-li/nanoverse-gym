"""Official RoboDojo goal rules applied to reconstructed, measured scenes.

This module is copied into each portable package. Scene assets, controllers and
physics stay owned by the task; only the private reward observation is extended.
"""

import itertools
import math

import numpy as np


def rotation(quaternion):
    q = np.asarray(quaternion, dtype=float)
    norm = np.linalg.norm(q)
    if q.shape != (4,) or not np.isfinite(q).all() or norm < 1e-10:
        raise ValueError("Scoring requires a finite, nonzero quaternion")
    w, x, y, z = q / norm
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def quaternion_distance(first, second):
    first, second = np.asarray(first, dtype=float), np.asarray(second, dtype=float)
    rotation(first)
    rotation(second)
    cosine = abs(float(first @ second / (np.linalg.norm(first) * np.linalg.norm(second))))
    return math.degrees(2 * math.acos(float(np.clip(cosine, 0, 1))))


def frame_distance(first, second):
    return math.degrees(math.acos(float(np.clip((np.trace(first.T @ second) - 1) / 2, -1, 1))))


def robot_observation(env, observation):
    """Read the same TCP poses and normalized finger values as Func_Parser.

    These extra fields belong to reward observations, never policy observations.
    Origin poses come from native reward initialization before policy controls.
    """
    manager = env.robot_manager
    origins = env.reward_manager.func_parser.robot_origin_endpose[0]
    endposes, origin_endposes, opened = [], [], []
    support_endposes, support_origins = [], []
    for robot in manager.robot_list:
        value = manager.get_real_endpose(robot)[0]
        if hasattr(value, "detach"):
            value = value.detach().cpu().numpy()
        if robot.type != "target":
            support_endposes.append(np.asarray(value, dtype=float).reshape(7))
            support_origins.append(np.asarray(origins[robot.arm_name], dtype=float).reshape(7))
            continue
        endposes.append(np.asarray(value, dtype=float).reshape(7))
        origin_endposes.append(np.asarray(origins[robot.arm_name], dtype=float).reshape(7))
        fingers = manager.get_end_effector_real_val(robot=robot, env_idx_list=[0])[0]
        if hasattr(fingers, "detach"):
            fingers = fingers.detach().cpu().numpy()
        low, high = robot.gripper_scale
        opened.append(float((np.asarray(fingers).mean() - low) / (high - low)))
    result = {
        **observation,
        "endposes": endposes,
        "origin_endposes": origin_endposes,
        "gripper_open_ratios": opened,
        "support_endposes": support_endposes,
        "support_origin_endposes": support_origins,
    }
    if "cloths" in observation:
        _, value = env.scene_manager.layout_manager.get_instance_pose(env_idx=0, label="shirt")
        if hasattr(value, "detach"):
            value = value.detach().cpu().numpy()
        result["garment_orientation"] = np.asarray(value, dtype=float).reshape(4)
    return result


def home(observation, position_threshold=0.15, rotation_threshold=20):
    poses = np.asarray(observation["endposes"], dtype=float)
    origins = np.asarray(observation["origin_endposes"], dtype=float)
    if poses.shape != (2, 7) or origins.shape != poses.shape or not np.isfinite(poses).all():
        raise ValueError("Home scoring requires both actual TCP poses and reset origins")
    if not np.isfinite(origins).all():
        raise ValueError("Home scoring requires finite reset TCP origins")
    return bool(
        np.all(np.abs(poses[:, :3] - origins[:, :3]) <= position_threshold)
        and all(quaternion_distance(p[3:], o[3:]) <= rotation_threshold for p, o in zip(poses, origins, strict=True))
    )


def axis_up(state, threshold=15, axis=(0, 0, 1)):
    return bool((rotation(state["orientation"]) @ np.asarray(axis))[2] > math.cos(math.radians(threshold)))


def local_point(state, reference, point=(0, 0, 0)):
    world = np.asarray(state["position"]) + rotation(state["orientation"]) @ np.asarray(point)
    return rotation(reference["orientation"]).T @ (world - reference["position"])


def stacked(states, labels, threshold, *, ordered=False, maximum_gap=None):
    if len(labels) < 2 or len(set(labels)) != len(labels):
        return False
    positions = [np.asarray(states[label]["position"], dtype=float) for label in labels]
    if not all(p.shape == (3,) and np.isfinite(p).all() for p in positions):
        raise ValueError("Stack scoring requires finite measured body positions")
    if not ordered:
        positions.sort(key=lambda p: p[2])
    return all(
        np.linalg.norm(b[:2] - a[:2]) <= threshold
        and b[2] - a[2] >= 0.005
        and (maximum_gap is None or b[2] - a[2] <= maximum_gap)
        for a, b in zip(positions[:-1], positions[1:], strict=True)
    )


def projected_hull(vertices):
    points = sorted(set(map(tuple, np.asarray(vertices)[:, :2])))
    if len(points) < 3:
        return np.empty((0, 2))

    def cross(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])

    lower, upper = [], []
    for selected, target in ((points, lower), (points[::-1], upper)):
        for point in selected:
            while len(target) >= 2 and cross(target[-2], target[-1], point) <= 0:
                target.pop()
            target.append(point)
    return np.asarray(lower[:-1] + upper[:-1])


def within_polygon(points, polygon, *, strict=True):
    points = np.atleast_2d(points)[:, :2]
    if len(polygon) < 3:
        return np.zeros(len(points), dtype=bool)
    edges = np.roll(polygon, -1, axis=0) - polygon
    delta = points[:, None, :] - polygon
    cross = edges[None, :, 0] * delta[:, :, 1] - edges[None, :, 1] * delta[:, :, 0]
    return np.all(cross > 0 if strict else cross >= -1e-10, axis=1)


def scattered_mask(points_xy, radius, minimum_size):
    """Match the official XY connected components without a dense N by N matrix."""
    points = np.asarray(points_xy, dtype=float)
    buckets = {}
    cells = np.floor(points / radius).astype(np.int64)
    for index, cell in enumerate(cells):
        buckets.setdefault(tuple(cell), []).append(index)
    visited, small = np.zeros(len(points), dtype=bool), np.zeros(len(points), dtype=bool)
    for start in range(len(points)):
        if visited[start]:
            continue
        pending, component = [start], []
        visited[start] = True
        while pending:
            index = pending.pop()
            component.append(index)
            cell = cells[index]
            for offset in itertools.product((-1, 0, 1), repeat=2):
                neighbors = buckets.get(tuple(cell + offset), ())
                candidates = [candidate for candidate in neighbors if not visited[candidate]]
                if not candidates:
                    continue
                delta = points[candidates] - points[index]
                close = np.einsum("ij,ij->i", delta, delta) <= radius * radius
                for candidate in np.asarray(candidates)[close]:
                    visited[candidate] = True
                    pending.append(int(candidate))
        if len(component) < minimum_size:
            small[component] = True
    return small


class OfficialRubric:
    """Use task context for sampled identities, without running its old scorer."""

    def __init__(self, context, *, spec, metadata, seed, initial):
        self.context, self.spec = context, spec
        self.metadata = metadata or {}
        self.seed, self.initial = int(seed), initial
        self.task = spec["name"]
        self.stage = 0
        self.violation = None
        self.best_partial_score = 0.0
        self.button_armed = {}
        self.button_counts = {}
        self.history = []
        self.demo_order = []
        self.discard = None
        self.previous_objects = None
        self.previous_upright = {}

    def _metadata(self, label):
        asset = self.spec["objects"][label]["asset"]
        retained = self.spec["official_scoring"].get("asset_geometry", {}).get(asset, {})
        return {**retained, **self.metadata.get(label, self.metadata.get(asset, {}))}

    def _vertices(self, label):
        metadata = self._metadata(label)
        geometry = metadata.get("geometry", {})
        if "oriented_bbox" in geometry:
            return np.asarray(geometry["oriented_bbox"]["vertices"], dtype=float)
        if "bounds_min" in geometry:
            bounds = [geometry["bounds_min"], geometry["bounds_max"]]
        elif "bounds" in metadata:
            bounds = metadata["bounds"]
        else:
            raise ValueError("Task is missing its reconstructed body bounds: " + label)
        return np.asarray(list(itertools.product(*np.asarray(bounds).T)))

    def _world_vertices(self, label, states):
        state = states[label]
        return self._vertices(label) @ rotation(state["orientation"]).T + state["position"]

    def _point_inside(self, label, container, states, *, upper_margin=None):
        vertices = self._world_vertices(container, states)
        point = np.asarray(states[label]["position"])
        inside = bool(within_polygon([point], projected_hull(vertices))[0] and point[2] > vertices[:, 2].min())
        if upper_margin is not None:
            inside &= bool(
                states[label]["position"][2] < self._world_vertices(container, states)[:, 2].max() + upper_margin
            )
        return inside

    def _covers(self, container, label, states):
        a, b = self._world_vertices(container, states), self._world_vertices(label, states)
        return bool(
            within_polygon(b, projected_hull(a)).all()
            and b[:, 2].max() < a[:, 2].max()
            and b[:, 2].min() > a[:, 2].min() - 0.03
        )

    def _depth(self, label, container, states):
        return float(
            self._world_vertices(container, states)[:, 2].max() - self._world_vertices(label, states)[:, 2].min()
        )

    def _count_score(self, count, tiers, observation, success, threshold=0.8):
        open_hands = min(observation["gripper_open_ratios"]) >= threshold
        if open_hands:
            self.best_partial_score = max(self.best_partial_score, tiers[min(count, len(tiers) - 2)] / 100.0)
        return tiers[-1] / 100.0 if success and open_hands else self.best_partial_score

    def _binary(self, ready, observation, details, *, require_home=True):
        returned = home(observation) if require_home else True
        success = bool(ready and returned)
        return success, float(success), {**details, "final_home": returned, "stable_seconds": 0.0}

    def step(self, observation, dt):
        if not np.isfinite(dt) or dt < 0:
            raise ValueError("Reward observations require a finite nonnegative interval")
        for state in observation["objects"].values():
            position = np.asarray(state["position"], dtype=float)
            if position.shape != (3,) or not np.isfinite(position).all():
                raise ValueError("Task scoring requires finite measured body positions")
            rotation(state["orientation"])
        method = getattr(self, "_" + self.task, None)
        if method is None:
            raise ValueError("No reviewed official grading rule for " + self.task)
        satisfied, score, details = method(observation)
        satisfied = bool(satisfied and self.violation is None)
        score = float(score)
        if self.violation is not None:
            # Official process modes retain achieved lower tiers after a failed
            # query; they withhold the 100-point completion tier.
            partial_limit = {
                "cover_blocks": 0.3,
                "fold_clothes": 0.2,
                "imitate_sorting_sequence": 0.5,
                "play_tic_tac_toe": 0.75,
                "pour_by_language": 0.5,
            }.get(self.task, 0.0)
            score = min(score, partial_limit)
        if not math.isfinite(score) or not 0 <= score <= 1:
            raise ValueError("Official grading produced an invalid score")
        return {
            **details,
            "success": satisfied,
            "satisfied": satisfied,
            "score": score,
            "criteria": {"official_task": {"weight": 1.0, "value": score, "score": score}},
            "evaluation_version": 3,
            "grading_profile": "robodojo_official",
            "violation": self.violation,
        }

    def _stack_bowls(self, observation):
        states = observation["objects"]
        labels = list(self.spec["objects"])
        if len(labels) != 3 or any(label not in states for label in labels):
            raise ValueError("Official bowl stacking requires all three measured bowls")
        order = sorted(labels, key=lambda label: states[label]["position"][2])
        upright = all(axis_up(states[label], 45) for label in labels)
        bottom_upright = axis_up(states[order[0]], 7)
        complete = upright and bottom_upright and stacked(states, labels, 0.04)
        returned = home(observation)
        open_hands = min(observation["gripper_open_ratios"]) >= 0.8
        pair = any(
            axis_up(states[a], 7) and axis_up(states[b], 45) and stacked(states, [a, b], 0.04, ordered=True)
            for a, b in itertools.permutations(labels, 2)
        )
        if pair and open_hands:
            self.best_partial_score = 0.15
        success = complete and returned
        score = 1.0 if success and open_hands else self.best_partial_score
        return (
            success,
            score,
            {
                "stack_order": order,
                "three_bowl_stack": bool(complete),
                "bottom_upright": bottom_upright,
                "all_bowls_upright": upright,
                "final_home": returned,
                "grippers_open": open_hands,
                "stable_seconds": 0.0,
            },
        )

    def _general_pickup(self, observation):
        target = self.context.target
        lift = float(observation["objects"][target]["position"][2] - self.initial[target]["position"][2])
        return self._binary(lift > 0.1, observation, {"target": target, "lift_height_m": lift}, require_home=False)

    def _align_blocks(self, observation):
        states = observation["objects"]
        labels = [name for name, definition in self.spec["objects"].items() if definition["asset"] == "block"]
        if len(labels) != 3:
            raise ValueError("Alignment requires three blocks")
        positions = np.asarray([states[name]["position"] for name in labels])
        centered = positions[:, :2] - positions[:, :2].mean(0)
        _, _, vectors = np.linalg.svd(centered)
        direction = np.r_[vectors[0], 0.0]
        normal = np.array([-direction[1], direction[0]])
        error = float(np.abs(centered @ normal).max())
        aligned = all(
            np.abs(rotation(states[name]["orientation"]).T @ direction).max() > math.cos(math.radians(8))
            for name in labels
        )
        if np.any(positions[:, 2] - [self.initial[name]["position"][2] for name in labels] > 0.007):
            self.violation = "A block exceeded the official 7 mm no-lift limit"
        return self._binary(
            error <= 0.008 and aligned,
            observation,
            {
                "row_error_m": error,
                "aligned_block_axes": bool(aligned),
                "no_lift_violation": self.violation is not None,
            },
        )

    def _stack_blocks(self, observation):
        states = observation["objects"]
        labels = list(self.context.labels)
        if len(labels) != 3:
            raise ValueError("Official block stacking requires all three blocks")
        # Reconstructed category 00000 uses the official unmapped-category fallback.
        threshold = 0.015
        complete = stacked(states, labels, threshold)
        success = complete and home(observation)
        pair = any(stacked(states, list(pair), threshold) for pair in itertools.combinations(labels, 2))
        score = self._count_score(int(pair) + int(complete), [0, 15, 100], observation, success)
        return success, score, {"stacked": complete, "planar_threshold_m": threshold, "final_home": home(observation)}

    def _stack_blocks_by_language(self, observation):
        states = observation["objects"]
        labels = ["block_0", "block_1", "block_2"]
        # Existing sampled order belongs to the authored task context.
        labels = list(self.context.order)
        complete = stacked(states, labels, 0.0175, ordered=True)
        success = complete and home(observation)
        pair = (
            stacked(states, labels[:2], 0.0175, ordered=True, maximum_gap=0.04)
            and states[labels[0]]["position"][2] - self.initial[labels[0]]["position"][2] <= 0.01
        )
        score = self._count_score(int(pair) + int(complete), [0, 20, 100], observation, success, threshold=0.92)
        return success, score, {"stacked": complete, "required_order": labels, "final_home": home(observation)}

    def _arrange_largest_number(self, observation):
        states, correct = observation["objects"], []
        for index, digit in enumerate(self.context.digits):
            state, pad = states[f"digit_{digit}"], states[f"pad_{index}"]
            xy = np.linalg.norm(np.asarray(state["position"])[:2] - np.asarray(pad["position"])[:2])
            frame = rotation(state["orientation"])
            y_aligned = (abs(frame[1, 1]) if digit == 0 else frame[1, 1]) > math.cos(math.radians(45))
            x_aligned = digit in (0, 8) or frame[0, 0] > math.cos(math.radians(45))
            correct.append(bool(xy < 0.02 and y_aligned and x_aligned))
        success = all(correct) and home(observation)
        tiers = [0, 5, 15, 30, 100] if len(correct) == 4 else [0, 5, 15, 25, 40, 100]
        return (
            success,
            self._count_score(sum(correct), tiers, observation, success),
            {
                "correct_digits": correct,
                "largest_number": "".join(map(str, self.context.digits)),
                "final_home": home(observation),
            },
        )

    def _solve_equation(self, observation):
        states = observation["objects"]
        label, pad = self.context.label, self.context.pad
        frame = rotation(states[label]["orientation"])
        xy = float(np.linalg.norm(np.asarray(states[label]["position"])[:2] - np.asarray(states[pad]["position"])[:2]))
        ready = xy < 0.018 and frame[0, 0] > math.cos(math.radians(45)) and frame[1, 1] > math.cos(math.radians(45))
        return self._binary(ready, observation, {"equation": self.context.equation, "xy_error_m": xy})

    def _sort_nesting_dolls_by_size(self, observation):
        states = observation["objects"]
        labels = self.context.labels
        positions = np.asarray([states[label]["position"] for label in labels])
        ordered = bool(np.all(np.diff(positions[:, 0]) > 0.03))
        spread = float(np.ptp(positions[:, 1]))
        upright = all(axis_up(states[label]) for label in labels)
        return self._binary(
            ordered and spread <= 0.035 and upright,
            observation,
            {"size_order": labels, "row_range_m": spread, "upright": upright},
        )

    def _classify_objects(self, observation):
        states = observation["objects"]
        categories = self.spec["classification"]["categories"]
        assignments = (
            [dict(zip(categories, permutation, strict=True)) for permutation in itertools.permutations(range(3))]
            if self.task == "classify_objects"
            else [self.context.assignment]
        )
        best = None
        for assignment in assignments:
            complete = {
                category: all(
                    self._point_inside(label, f"basket_{assignment[category]}", states, upper_margin=0.01)
                    for label in labels
                )
                for category, labels in categories.items()
            }
            count = sum(complete.values())
            if best is None or count > best[0]:
                best = count, assignment, complete
        count, assignment, complete = best
        success = count == 3 and home(observation)
        tiers = [0, 15, 40, 100] if self.task == "classify_objects" else [0, 10, 40, 100]
        return (
            success,
            self._count_score(count, tiers, observation, success),
            {"complete_categories": complete, "assignment": assignment, "final_home": home(observation)},
        )

    _classify_objects_by_language = _classify_objects

    def _deposit_coin(self, observation):
        states = observation["objects"]
        coin, bank = states["coin"], states["bank"]
        corners = self._world_vertices("coin", states)
        local = (corners - bank["position"]) @ rotation(bank["orientation"])
        bank_meta = self.metadata["bank"]
        bounds = self._vertices("bank")
        inside = bool(
            np.all(local[:, :2] > bounds[:, :2].min(0))
            and np.all(local[:, :2] < bounds[:, :2].max(0))
            and local[:, 2].min() > bank_meta["chute_bottom"]
            and local[:, 2].max() < bank_meta["chute_top"]
        )
        lift = coin["position"][2] - self.initial["coin"]["position"][2]
        if lift > 0.08:
            self.best_partial_score = 0.2
        success = inside and home(observation)
        return (
            success,
            1.0 if success else self.best_partial_score,
            {"deposited": inside, "final_home": home(observation)},
        )

    def _fasten_screws(self, observation):
        states, complete = observation["objects"], []
        for index in range(3):
            nut, bolt = f"nut_{index}", f"bolt_{index}"
            xy = np.linalg.norm(np.asarray(states[nut]["position"])[:2] - np.asarray(states[bolt]["position"])[:2])
            complete.append(bool(axis_up(states[nut], 10) and xy < 0.001 and self._depth(nut, bolt, states) > 0.009))
        success = all(complete) and min(observation["gripper_open_ratios"]) >= 0.9 and home(observation)
        score = self._count_score(sum(complete), [0, 20, 50, 100], observation, success)
        return success, score, {"complete_pairs": complete, "final_home": home(observation)}

    def _fill_pen_holder(self, observation):
        states, inserted = observation["objects"], []
        holder = states["holder"]
        for label in (label for label in self.spec["objects"] if label != "holder"):
            local = local_point(states[label], holder)
            up = rotation(states[label]["orientation"])[2, 2]
            inserted.append(
                bool(
                    np.linalg.norm(local[:2]) < 0.035
                    and self.metadata["holder"]["height"] - local[2] > 0.035
                    and up > 0
                )
            )
        success = all(inserted) and axis_up(holder) and home(observation)
        score = self._count_score(
            sum(inserted), [0, 10, 25, 40, 90], observation, all(inserted) and axis_up(holder, 45)
        )
        return success, score, {"inserted_pens": inserted, "final_home": home(observation)}

    def _insert_tubes(self, observation):
        states = observation["objects"]
        seated = [
            self._point_inside(label, "rack", states)
            and self._depth(label, "rack", states) > 0.045
            and axis_up(states[label], 30)
            for label in (f"tube_{i}" for i in range(3))
        ]
        success = all(seated) and home(observation)
        return (
            success,
            self._count_score(sum(seated), [0, 20, 40, 100], observation, success),
            {"seated_tubes": seated, "final_home": home(observation)},
        )

    def _plug_in_charger(self, observation):
        states = observation["objects"]
        ready = (
            self._point_inside("charger", "strip", states)
            and self._depth("charger", "strip", states) > 0.015
            and axis_up(states["charger"], 10)
        )
        return self._binary(ready, observation, {"inserted": bool(ready)})

    def _put_bottles_into_dustbin(self, observation):
        states = observation["objects"]
        labels = [label for label in self.spec["objects"] if label != "bin"]
        floor = self._world_vertices("bin", states)[:, 2].min()
        contained = [
            self._covers("bin", label, states) and 0 <= self._world_vertices(label, states)[:, 2].min() - floor <= 0.4
            for label in labels
        ]
        success = all(contained) and home(observation)
        return (
            success,
            self._count_score(sum(contained), [0, 10, 25, 40, 100], observation, success),
            {"contained_bottles": contained, "final_home": home(observation)},
        )

    def _push_t(self, observation):
        states = observation["objects"]
        moving, target = states["block"], states["target"]
        xy = float(np.linalg.norm(np.asarray(moving["position"])[:2] - np.asarray(target["position"])[:2]))
        angle = quaternion_distance(moving["orientation"], target["orientation"])
        if moving["position"][2] - self.initial["block"]["position"][2] > 0.01:
            self.violation = "The T exceeded the official 10 mm no-lift limit"
        return self._binary(xy < 0.007 and angle < 7, observation, {"xy_error_m": xy, "orientation_error_deg": angle})

    def _swap_t(self, observation):
        states, fitted = observation["objects"], {}
        for label, target in self.context.targets.items():
            state = states[label]
            fitted[label] = bool(
                np.linalg.norm(np.asarray(state["position"])[:2] - np.asarray(target["position"])[:2]) < 0.02
                and quaternion_distance(state["orientation"], target["orientation"]) < 3
            )
        return self._binary(all(fitted.values()), observation, {"swapped_poses": fitted})

    def _match_and_pick_from_conveyor(self, observation):
        label = self.context.plan["target_label"]
        lift = float(observation["objects"][label]["position"][2] - self.initial[label]["position"][2])
        return self._binary(lift > 0.1, observation, {"target_label": label, "target_lift_m": lift}, require_home=False)

    def _pick_from_conveyor_by_image(self, observation):
        states, label = observation["objects"], self.context.plan["target_label"]
        gap = float(
            self._world_vertices(label, states)[:, 2].min() - self._world_vertices("basket", states)[:, 2].min()
        )
        lift = float(states[label]["position"][2] - self.initial[label]["position"][2])
        ready = -0.01 <= gap <= 0.04 and self._covers("basket", label, states) and lift > 0.08
        return self._binary(
            ready,
            observation,
            {"target_label": label, "target_lift_m": lift, "basket_bottom_gap_m": gap},
            require_home=False,
        )

    def _fill_egg_holder(self, observation):
        states = observation["objects"]
        bottom = self._metadata("holder")["geometry"]["bounds_min"][2]
        eggs = [
            self._point_inside(f"egg_{i}", "holder", states)
            and 0.0 < local_point(states[f"egg_{i}"], states["holder"])[2] - bottom < 0.04
            for i in range(4)
        ]
        relative = rotation(states["holder"]["orientation"]).T @ rotation(states["lid"]["orientation"])
        angle = math.degrees(math.atan2(relative[2, 1], relative[1, 1]))
        low, high = self.spec["joints"]["lid_hinge"]["limits"]
        closed = (angle - low) / (high - low) > 0.9
        success = all(eggs) and closed and home(observation)
        # The official process score has a 90-point final egg-placement tier.
        score = self._count_score(sum(eggs), [0, 10, 25, 40, 90], observation, all(eggs))
        return (
            success,
            score,
            {"eggs_inside": eggs, "lid_closed": bool(closed), "lid_angle_deg": angle, "final_home": home(observation)},
        )

    def _insert_key(self, observation):
        states = observation["objects"]
        key, rotor, housing = states["key"], states["rotor"], states["housing"]
        local = local_point(key, rotor)
        depth = self.metadata["rotor"]["slot_top"] - local[2]
        key_axis = rotation(housing["orientation"]).T @ rotation(key["orientation"])[:, 0]
        # The reconstructed rotor guide is mirrored: its supported turn is +60
        # degrees, corresponding to the official slot's -60-degree active frame.
        aligned = float(key_axis @ np.array([0.5, math.sqrt(3) / 2, 0])) > math.cos(math.radians(30))
        ready = depth > 0.025 and np.linalg.norm(local[:2]) < 0.007 and axis_up(key, 7) and aligned
        lift = key["position"][2] - self.initial["key"]["position"][2]
        if lift > 0.05:
            self.best_partial_score = 0.15
        return (
            ready,
            1.0 if ready else self.best_partial_score,
            {"inserted": bool(ready), "depth_m": float(depth), "turned_axis_aligned": aligned},
        )

    def _pour_balls_into_vase(self, observation):
        states = observation["objects"]
        inside = [self._point_inside(f"ball_{i}", "vase", states) for i in range(7)]
        ready = all(inside) and axis_up(states["cup"])
        return self._binary(ready, observation, {"balls_inside": inside, "count_inside": sum(inside)})

    def _play_stacking_toy(self, observation):
        states, groups = observation["objects"], self.context.groups
        centers = self.spec["goal"]["peg_centers"]
        completed = []
        for group, labels in groups.items():
            labels = sorted(labels)
            points = [local_point(states[label], states["base"]) for label in labels]
            aligned = np.linalg.norm(points[0][:2] - centers[group]) < 0.001
            aligned &= all(np.linalg.norm(b[:2] - a[:2]) < 0.001 for a, b in zip(points[:-1], points[1:], strict=True))
            inserted = all(self._depth(label, "base", states) > 0.005 for label in labels)
            completed.append(bool(aligned and inserted))
        success = all(completed) and home(observation)
        return (
            success,
            self._count_score(sum(completed), [0, 10, 30, 60, 100], observation, success),
            {"peg_groups": dict(zip(groups, completed, strict=True)), "final_home": home(observation)},
        )

    def _pack_objects_into_box(self, observation):
        states, packed = observation["objects"], {}
        box = states["box"]
        frame = rotation(box["orientation"])
        aligned_box = abs(float(frame[0, 0])) > math.cos(math.radians(40))
        upright = axis_up(box)
        half = np.asarray(self.metadata["box"]["inner_half_size"])
        for label in ("hammer", "driver", "tape", "slipper"):
            point = local_point(states[label], box)
            front = rotation(states[label]["orientation"])[:, 0][:2]
            front_norm = np.linalg.norm(front)
            if front_norm < 1e-10:
                packed[label] = False
                continue
            front /= front_norm
            box_axis = frame[:2, 0] / np.linalg.norm(frame[:2, 0])
            packed[label] = bool(
                np.all(np.abs(point[:2]) <= half + 1e-6)
                and front[0] < -math.cos(math.radians(60))
                and abs(float(front @ box_axis)) > math.cos(math.radians(45))
                and upright
            )
        success = all(packed.values()) and aligned_box and home(observation)
        score = self._count_score(
            sum(packed.values()) if aligned_box else 0, [0, 10, 25, 50, 100], observation, success
        )
        return success, score, {"packed_objects": packed, "box_aligned": aligned_box, "final_home": home(observation)}

    def _build_tower(self, observation):
        states = observation["objects"]
        upright = all(axis_up(states[label], 5) for label in self.spec["objects"])
        supports = ["lower_left", "lower_right", "middle_left", "middle_right"]
        heights = {label: states[label]["position"][2] for label in self.spec["objects"]}
        low = [label for label in supports if heights["lower_board"] - heights[label] > 0.025]
        upper = [label for label in supports if heights[label] - heights["lower_board"] > 0.025]
        base = len(low) >= 2 and axis_up(states["lower_board"], 5)
        middle = (
            base
            and len(upper) >= 2
            and all(heights["middle_board"] - heights[label] > 0.025 for label in upper)
            and np.linalg.norm(
                np.asarray(states["middle_board"]["position"])[:2] - np.asarray(states["lower_board"]["position"])[:2]
            )
            < 0.043
        )
        top = (
            middle
            and heights["upper_support"] - heights["middle_board"] > 0.012
            and heights["top_board"] - heights["upper_support"] > 0.015
            and np.linalg.norm(
                np.asarray(states["upper_support"]["position"])[:2] - np.asarray(states["middle_board"]["position"])[:2]
            )
            < 0.023
            and np.linalg.norm(
                np.asarray(states["top_board"]["position"])[:2] - np.asarray(states["upper_support"]["position"])[:2]
            )
            < 0.023
        )
        parallel = all(
            abs(float(rotation(states[a]["orientation"])[:, 0] @ rotation(states[b]["orientation"])[:, 0]))
            > math.cos(math.radians(20))
            for a, b in (("upper_support", "middle_board"), ("top_board", "upper_support"))
        )
        complete = top and upright and parallel
        success = complete and home(observation)
        stage = 3 if complete else 2 if middle and upright else 1 if base else 0
        return (
            success,
            self._count_score(stage, [0, 10, 30, 100], observation, success),
            {
                "lower_layer": base,
                "middle_layer": middle,
                "complete_tower": bool(complete),
                "final_home": home(observation),
            },
        )

    def _hang_mugs(self, observation):
        states, hung = observation["objects"], []
        rack = states["rack"]
        rack_rotation = rotation(rack["orientation"])
        center = np.asarray(self.metadata["mug"]["handle"]["center"])
        for label in (f"mug_{i}" for i in range(3)):
            state = states[label]
            frame = rotation(state["orientation"])
            handle = np.asarray(state["position"]) + frame @ center
            lift = state["position"][2] - self.initial[label]["position"][2]
            aligned = False
            for hook in self.metadata["rack"]["hooks"]:
                tip = np.asarray(rack["position"]) + rack_rotation @ np.asarray(hook["end"])
                axis = rack_rotation @ np.asarray(hook["axis"])
                sideways = np.cross([0, 0, 1], axis)
                sideways /= np.linalg.norm(sideways)
                aligned |= bool(
                    np.linalg.norm(handle - tip) < 0.045
                    and abs(float(frame[:, 1] @ axis)) > 0.5
                    and abs(float(frame[:, 0] @ sideways)) > 0.5
                )
            hung.append(bool(lift > 0.045 and handle[2] > 0.9 and aligned))
        success = all(hung) and home(observation)
        return (
            success,
            self._count_score(sum(hung), [0, 15, 40, 100], observation, success),
            {"hung_mugs": hung, "final_home": home(observation)},
        )

    def _sweep_blocks(self, observation):
        states = observation["objects"]
        pan, broom = states["dustpan"], states["broom"]
        labels = [name for name, definition in self.spec["objects"].items() if definition["asset"] == "block"]
        outline = np.asarray(self.metadata["dustpan"]["interior_outline"])
        polygon = projected_hull(np.column_stack([outline, np.zeros(len(outline))]))
        contained = [
            bool(
                within_polygon([local_point(states[label], pan)], polygon)[0] and local_point(states[label], pan)[2] > 0
            )
            for label in labels
        ]
        low = pan["position"][2] - self.initial["dustpan"]["position"][2] <= 0.01
        left = broom["position"][0] - pan["position"][0] > 0.1
        ready = all(contained) and low and left and axis_up(pan, 5)
        return self._binary(
            ready, observation, {"contained": contained, "pan_left_of_broom": bool(left), "pan_not_lifted": bool(low)}
        )

    def _button_edge(self, name, depth, limits):
        low, high = limits
        ratio = (-depth - low) / (high - low)
        event = False
        if ratio > 0.9:
            self.button_armed[name] = True
        elif ratio < 0.5 and self.button_armed.get(name, False):
            event = True
            self.button_armed[name] = False
            self.button_counts[name] = self.button_counts.get(name, 0) + 1
        return event, ratio

    def _press_by_number(self, observation):
        states, ratios = observation["objects"], {}
        for name in ("0", "1", "confirm"):
            joint = self.spec["joints"]["spring_" + name]
            local = local_point(states["cap_" + name], states["base_" + name])
            event, ratios[name] = self._button_edge(name, joint["anchor0"][2] - local[2], joint["limits"])
            if not event:
                continue
            targets = list(self.context.targets)
            counts = [self.button_counts.get("0", 0), self.button_counts.get("1", 0)]
            if name == "confirm":
                if self.stage == 0 and counts == [targets[0], 0]:
                    self.stage = 1
                elif self.stage == 1 and counts == targets:
                    self.stage = 2
                else:
                    self.violation = "Confirmation did not follow the official exact button counts"
            elif int(name) != self.stage or counts[int(name)] > targets[int(name)]:
                self.violation = "A numbered button exceeded its count or was pressed out of order"
            self.history.append({"button": name, "stage": self.stage})
        success = (
            self.stage == 2
            and ratios["confirm"] > 0.9
            and home(observation)
            and self.button_counts.get("confirm", 0) == 2
            and self.violation is None
        )
        return (
            success,
            float(success),
            {
                "phase": self.stage,
                "targets": list(self.context.targets),
                "counts": dict(self.button_counts),
                "button_ratios": ratios,
                "events": list(self.history),
                "final_home": home(observation),
            },
        )

    def _swap_blocks(self, observation):
        states = observation["objects"]
        origins, empty = self.context.origins, self.context.empty
        locations = []
        for index in range(2):
            distances = [
                np.linalg.norm(np.asarray(states[f"block_{index}"]["position"]) - states[f"mat_{mat}"]["position"])
                for mat in range(3)
            ]
            location = int(np.argmin(distances))
            locations.append(location if distances[location] < 0.03 else None)
        if not hasattr(self, "first"):
            moved = [i for i in range(2) if locations[i] == empty and locations[1 - i] == origins[1 - i]]
            if len(moved) == 1:
                self.first = moved[0]
        expected = list(origins)
        if hasattr(self, "first"):
            first, other = self.first, 1 - self.first
            expected[first] = empty
            if self.stage >= 1:
                expected[other] = origins[first]
            if self.stage >= 2:
                expected[first] = origins[other]
        joint = self.spec["joints"]["button_slide"]
        local = local_point(states["button_cap"], states["button_base"])
        event, ratio = self._button_edge("confirm", joint["anchor0"][2] - local[2], joint["limits"])
        if event:
            valid = self.stage < 3 and hasattr(self, "first") and locations == expected
            self.history.append({"stage": self.stage, "locations": locations, "valid": valid})
            if valid:
                self.stage += 1
            else:
                self.violation = "Button confirmation did not follow the required temporary-mat swap"
        success = (
            self.stage == 3
            and locations == origins[::-1]
            and ratio > 0.9
            and self.button_counts.get("confirm", 0) == 3
            and home(observation)
        )
        return (
            success,
            float(success and self.violation is None),
            {
                "phase": self.stage,
                "locations": locations,
                "events": list(self.history),
                "final_home": home(observation),
            },
        )

    def _cover_blocks(self, observation):
        states = observation["objects"]
        cups = [f"cup_{i}" for i in range(3)]
        colors = ["red", "green", "blue"]
        covered = {color: any(self._covers(cup, color, states) for cup in cups) for color in colors}
        if any(
            np.linalg.norm(np.asarray(states[color]["position"]) - self.initial[color]["position"]) > 0.05
            for color in colors
        ):
            self.violation = "A block exceeded the official 50 mm no-movement limit"
        up = all(axis_up(states[cup], 10) for cup in cups)
        order = sorted(colors, key=lambda color: self.initial[color]["position"][0])
        targets = [set(order[:1]), set(order[:2]), set(order), {"green", "blue"}, {"blue"}, set()]
        current = {color for color, value in covered.items() if value}
        if self.stage < 6 and up and current == targets[self.stage]:
            if self.stage < 5 or home(observation):
                self.history.append({"stage": self.stage, "covered": sorted(current)})
                self.stage += 1
        success = self.stage == 6 and not current and up and home(observation)
        gradient = [0, 0, 5, 15, 30, 100]
        score = gradient[min(self.stage - 1, 4)] / 100.0 if self.stage > 0 else 0.0
        return (
            success,
            1.0 if success else score,
            {"phase": self.stage, "covered": covered, "events": list(self.history), "final_home": home(observation)},
        )

    def _fold_clothes(self, observation):
        cloth = observation["cloths"]["shirt"]
        positions = np.asarray(cloth["positions"], dtype=float)
        metadata = self.metadata["_cloths"]["shirt"]
        if (
            cloth["measurement"] != "physx_particle_cloth_tensor"
            or positions.shape != (metadata["vertex_count"], 3)
            or not np.isfinite(positions).all()
        ):
            raise ValueError("Folding requires the complete measured native cloth tensor")
        points = {name: positions[indices].mean(0) for name, indices in metadata["landmarks"].items()}
        frame = rotation(observation["garment_orientation"])
        sleeves, far_sleeves = [], []
        for side, other in (("left", "right"), ("right", "left")):
            delta = frame.T @ (points[side + "_cuff"] - points[other + "_chest"])
            lower, upper = (-0.125, 0.14) if side == "left" else (-0.14, 0.125)
            sleeves.append(bool(lower < delta[0] < upper and -0.125 < delta[1] < 0.14))
            far_sleeves.append(not (lower < delta[0] < upper) and not (-0.125 < delta[1] < 0.14))
        hems = []
        for side in ("left", "right"):
            delta = frame.T @ (points[side + "_hem"] - points[side + "_shoulder"])
            hems.append(bool(-0.12 < delta[0] < 0.12 and -0.095 < delta[1] < 0.17))
        hem = points["right_hem"] - points["left_hem"]
        shoulder = points["right_shoulder"] - points["left_shoulder"]
        norm = np.linalg.norm(hem[:2]) * np.linalg.norm(shoulder[:2])
        aligned = norm > 1e-10 and float(hem[:2] @ shoulder[:2]) / norm > math.cos(math.radians(45))
        home_flags = [
            np.all(np.abs(np.asarray(p)[:3] - np.asarray(o)[:3]) <= 0.15) and quaternion_distance(p[3:], o[3:]) <= 20
            for p, o in zip(observation["endposes"], observation["origin_endposes"], strict=True)
        ]
        previous = getattr(self, "previous_fold_home", [False, False])
        if any(now and not before for now, before in zip(home_flags, previous, strict=True)):
            if any(far_sleeves) and all(hems) and aligned:
                self.violation = "A home trigger observed the final hem fold before both sleeves were folded"
        self.previous_fold_home = home_flags
        opened = min(observation["gripper_open_ratios"]) >= 0.7
        success = all(sleeves) and all(hems) and aligned and opened and home(observation)
        if all(sleeves) and opened:
            self.best_partial_score = 0.2
        return (
            success,
            1.0 if success else self.best_partial_score,
            {
                "sleeves_folded": sleeves,
                "hems_folded": hems,
                "hem_aligned": bool(aligned),
                "grippers_open": opened,
                "final_home": home(observation),
            },
        )

    def _opponent_query(self, observation):
        targets = zip(observation["endposes"], observation["origin_endposes"], strict=True)
        target_away = any(
            np.any(np.abs(np.asarray(p)[:3] - np.asarray(o)[:3]) > 0.3) or quaternion_distance(p[3:], o[3:]) > 30
            for p, o in targets
        )
        poses, origins = observation["support_endposes"], observation["support_origin_endposes"]
        if len(poses) != 1 or len(origins) != 1:
            raise ValueError("The official opponent task requires its real support robot TCP")
        p, o = poses[0], origins[0]
        support_away = (
            np.any(np.abs(np.asarray(p)[:3] - np.asarray(o)[:3]) > 0.3) or quaternion_distance(p[3:], o[3:]) > 40
        )
        if target_away and support_away:
            self.violation = "A target arm departed while the support arm was away, violating the official query"

    def _imitate_sorting_sequence(self, observation):
        self._opponent_query(observation)
        states = observation["objects"]
        kinds = [
            label.removeprefix("player_")
            for label in self.spec["objects"]
            if label.startswith("player_") and label != "player_bin"
        ]
        demo = {kind for kind in kinds if self._point_inside("demo_" + kind, "demo_bin", states)}
        player = {kind for kind in kinds if self._point_inside("player_" + kind, "player_bin", states)}
        new = demo - set(self.demo_order)
        if len(new) == 1:
            self.demo_order.extend(new)
        if len(self.demo_order) == 5 and len(demo) == 5 and self.stage < 5:
            expected = set(self.demo_order[: self.stage + 1])
            if player == expected:
                self.stage += 1
                self.history.append(self.demo_order[self.stage - 1])
        current = player == set(self.demo_order[: self.stage]) and len(demo) == 5
        success = self.stage == 5 and current and home(observation)
        score = self._count_score(self.stage if current else 0, [0, 5, 15, 30, 50, 100], observation, success)
        return (
            success,
            score,
            {
                "observed_demo_order": list(self.demo_order),
                "observed_policy_order": list(self.history),
                "demo_complete": len(demo) == 5,
                "final_home": home(observation),
            },
        )

    def _play_tic_tac_toe(self, observation):
        self._opponent_query(observation)
        states, cells = observation["objects"], {}
        board = states["board"]
        spacing = self.metadata["board"]["cell_spacing"]
        centers = np.asarray([[x * spacing, y * spacing] for y in (-1, 0, 1) for x in (-1, 0, 1)])
        for label in (label for label in self.spec["objects"] if label != "board"):
            local = local_point(states[label], board)
            distances = np.linalg.norm(centers - local[:2], axis=1)
            index = int(np.argmin(distances))
            if distances[index] < 0.015 and 0 < local[2] < 0.02:
                cells[label] = index
        player_count = sum(label.startswith("player_") for label in cells)
        success = len(cells) == 9
        score = self._count_score(player_count, [0, 10, 30, 50, 75, 100], observation, success)
        return (
            success,
            score,
            {"cells": cells, "player_marks": player_count, "opponent_marks": len(cells) - player_count},
        )

    def _make_toast(self, observation):
        states, toaster = observation["objects"], observation["objects"]["toaster"]
        labels = [f"bread_{i}" for i in range(4)]
        up = all(abs(rotation(states[label]["orientation"])[2, 2]) > math.cos(math.radians(30)) for label in labels)
        candidates = []
        for slot in self.metadata["toaster"]["slots"]:
            center, opening = np.asarray(slot["center"]), np.asarray(slot["opening"])
            candidates.append(
                {
                    label
                    for label in labels
                    if np.all(np.abs(local_point(states[label], toaster)[:2] - center[:2]) <= opening / 2 + 1e-6)
                    and 0.03 < local_point(states[label], toaster)[2] - slot["bottom"] < 0.065
                }
            )
        two = any(a != b for a in candidates[0] for b in candidates[1])
        count = 2 if two else int(bool(candidates[0] or candidates[1]))
        spare = sum(self._point_inside(label, "rack", states) for label in labels)
        joint = self.spec["joints"]["lever_slide"]
        lever_depth = joint["anchor0"][2] - local_point(states["lever"], toaster)[2]
        pressed = lever_depth / (joint["limits"][1] - joint["limits"][0]) > 0.85
        success = two and up and spare == 2 and pressed and home(observation)
        if up and min(observation["gripper_open_ratios"]) >= 0.8:
            self.best_partial_score = max(self.best_partial_score, [0.0, 0.25, 0.5][count])
        return (
            success,
            self.best_partial_score,
            {
                "inserted_slots": count,
                "spare_breads": spare,
                "lever_pressed": bool(pressed),
                "final_home": home(observation),
            },
        )

    def _organize_table(self, observation):
        states = observation["objects"]
        labels = ("mouse", "keyboard", "figurine", "alarm_clock")
        if self.previous_objects is None:
            self.previous_objects = {label: np.asarray(self.initial[label]["position"]) for label in labels}
        still = {
            label: np.linalg.norm(np.asarray(states[label]["position"]) - self.previous_objects[label]) <= 0.002
            for label in labels
        }
        self.previous_objects = {label: np.asarray(states[label]["position"]).copy() for label in labels}
        mouse_axis = rotation(states["mouse"]["orientation"])[:, 0]
        keyboard_axis = rotation(states["keyboard"]["orientation"])[:, 1]
        figurine_delta = np.asarray(states["figurine"]["position"]) - states["figurine_stand"]["position"]
        clock_target_z = states["cabinet"]["position"][2] + self.metadata["cabinet"]["clock_origin"][2]
        placements = {
            "mouse": bool(
                still["mouse"]
                and self._point_inside("mouse", "mousepad", states)
                and mouse_axis[0] > math.cos(math.radians(45))
            ),
            "keyboard": bool(
                still["keyboard"]
                and self._point_inside("keyboard", "keyboard_frame", states)
                and keyboard_axis[1] > math.cos(math.radians(45))
                and axis_up(states["keyboard"])
            ),
            "figurine": bool(
                still["figurine"]
                and 0.005 < figurine_delta[2] < 0.1
                and np.linalg.norm(figurine_delta[:2]) < 0.02
                and axis_up(states["figurine"])
            ),
            # The original clock-height window is 75 mm wide. Its center maps
            # to this reconstructed cabinet's authored clock support point.
            "alarm_clock": bool(
                still["alarm_clock"]
                and abs(states["alarm_clock"]["position"][2] - clock_target_z) < 0.0375
                and axis_up(states["alarm_clock"])
            ),
        }
        success = all(placements.values()) and home(observation)
        return (
            success,
            self._count_score(sum(placements.values()), [0, 25, 50, 75, 100], observation, success),
            {"placements": placements, "final_home": home(observation)},
        )

    def _store_tools_in_toolbox(self, observation):
        states, box = observation["objects"], observation["objects"]["toolbox"]
        placements, slot_only = {}, {}
        for label, slot in self.metadata["toolbox"]["slots"].items():
            point = local_point(states[label], box)
            yaw = math.radians(slot["yaw_deg"])
            target = rotation([math.cos(yaw / 2), 0, 0, math.sin(yaw / 2)])
            actual = rotation(box["orientation"]).T @ rotation(states[label]["orientation"])
            angles = [frame_distance(actual, target)]
            if label == "pliers":
                angles.append(frame_distance(actual, target @ np.diag([-1, -1, 1])))
            close = np.linalg.norm(point - slot["position"]) < 0.05
            slot_only[label] = bool(close)
            placements[label] = bool(close and min(angles) < 10 and self._covers("lid", label, states))
        success = all(placements.values()) and home(observation)
        score = self._count_score(sum(slot_only.values()), [0, 25, 50, 75, 100], observation, success)
        return success, score, {"placements": placements, "final_home": home(observation)}

    def _store_laptop_and_headphones(self, observation):
        states = observation["objects"]
        headphones, stand = states["headphones"], states["headphone_stand"]
        point = local_point(headphones, stand)
        relative = rotation(stand["orientation"]).T @ rotation(headphones["orientation"])
        hung = (
            np.linalg.norm(point - self.metadata["headphone_stand"]["headphone_origin"]) < 0.05
            and min(frame_distance(relative, np.eye(3)), frame_distance(relative, np.diag([-1, -1, 1]))) < 30
        )
        base, lid = states["laptop_base"], states["laptop_lid"]
        hinge = rotation(base["orientation"]).T @ rotation(lid["orientation"])
        angle = math.degrees(math.atan2(hinge[2, 1], hinge[1, 1]))
        low, high = self.spec["joints"]["laptop_hinge"]["limits"]
        closed = (angle - low) / (high - low) > 0.85
        vertical = abs(float(rotation(base["orientation"])[2, 1])) > math.cos(math.radians(10))
        corners = self._world_vertices("laptop_base", states)
        bottom_points = corners[corners[:, 2] <= corners[:, 2].min() + 1e-6]
        bottom = bottom_points.mean(0)
        rack = self._world_vertices("vertical_rack", states)
        inserted = bool(within_polygon([bottom], projected_hull(rack))[0] and bottom[2] > rack[:, 2].min())
        stored = closed and vertical and inserted
        ratios = observation["gripper_open_ratios"]
        if hung and min(ratios) >= 0.8:
            self.button_counts["headphones_achieved"] = 1
        if stored and min(ratios) >= 0.7:
            self.button_counts["laptop_achieved"] = 1
        success = bool(hung and stored and home(observation))
        achieved = 0.2 * self.button_counts.get("headphones_achieved", 0) + 0.8 * self.button_counts.get(
            "laptop_achieved", 0
        )
        score = 0.2 if achieved == 1 and not success else achieved
        return (
            success,
            score,
            {
                "headphones_hung": bool(hung),
                "laptop_closed": bool(closed),
                "laptop_stored": bool(stored),
                "hinge_angle_deg": angle,
                "final_home": home(observation),
            },
        )

    def _play_xylophone(self, observation):
        states, mallet = observation["objects"], observation["objects"]["mallet"]
        head = local_point(mallet, states["instrument"], self.metadata["mallet"]["head_center"])
        if self.stage >= 8:
            return True, 1.0, {"completed_note_stages": self.stage, "events": list(self.history)}
        if self.stage % 2 == 0:
            key = self.metadata["instrument"]["keys"][self.stage // 2]
            delta = head - np.asarray(key["center"])
            at_note = (
                abs(delta[0]) <= key["width"] / 2 + 1e-6
                and abs(delta[1]) <= key["length"] / 2 + 1e-6
                and 0.01 < delta[2] < 0.036
            )
            if at_note:
                self.history.append({"note": self.stage // 2, "head_position": head.tolist()})
                self.note_origin_z = float(mallet["position"][2])
                self.stage += 1
        elif mallet["position"][2] - self.note_origin_z > 0.025:
            self.stage += 1
        success = self.stage == 8
        return success, float(success), {"completed_note_stages": self.stage, "events": list(self.history)}

    def _make_kong(self, observation):
        self._opponent_query(observation)
        states = observation["objects"]
        advanced = [
            label
            for label in states
            if label.startswith("discard_") and states[label]["position"][1] < self.initial[label]["position"][1] - 0.1
        ]
        if self.discard is None and len(advanced) == 1:
            self.discard = advanced[0]
        if self.discard is None:
            return False, 0.0, {"observed_discard": None}
        identity = self.spec["assets"][self.spec["objects"][self.discard]["asset"]]["identity"]
        matching = [
            label
            for label, definition in self.spec["objects"].items()
            if label.startswith("player_") and self.spec["assets"][definition["asset"]]["identity"] == identity
        ]
        others = [label for label in states if label.startswith("player_") and label not in matching]
        common = (
            len(matching) == 3
            and all(axis_up(states[label], 30, axis=(0, -1, 0)) for label in matching)
            and all(axis_up(states[label], 7) for label in others)
        )
        discarded = states[self.discard]
        mapping = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, -1.0], [0.0, 1.0, 0.0]])
        target_frame = rotation([0.0, math.sqrt(0.5), math.sqrt(0.5), 0.0]) @ mapping.T
        if self.stage == 0 and common and frame_distance(rotation(discarded["orientation"]), target_frame) < 7:
            self.stage = 1
        xy = np.linalg.norm(np.asarray(discarded["position"])[:2] - np.asarray(states["marker"]["position"])[:2])
        success = (
            self.stage == 1
            and common
            and axis_up(discarded, 7)
            and xy < 0.015
            and min(observation["gripper_open_ratios"]) >= 0.6
        )
        return (
            success,
            float(success),
            {
                "observed_discard": self.discard,
                "matching_tiles": matching,
                "common_tile_checks": bool(common),
                "first_pose_recorded": self.stage == 1,
            },
        )

    def _fluid_ready(self, observation, fluid_name, source, target, *, language):
        from liquid_observations import require_physical_liquid

        fluid = observation["liquids"][fluid_name]
        require_physical_liquid(fluid)
        points = np.asarray(fluid["positions"], dtype=float)
        count = self.context.counts[fluid_name] if language else self.context.expected_count
        if points.shape != (count, 3) or not np.isfinite(points).all():
            raise ValueError("Liquid grading requires all original particles and finite physics coordinates")
        states = observation["objects"]

        def inside(label, minimum_z):
            vertices = self._vertices(label)
            lower, upper = vertices.min(0), vertices.max(0)
            state = states[label]
            local = (points - state["position"]) @ rotation(state["orientation"])
            return np.all((local >= lower) & (local <= upper), axis=1) & (local[:, 2] - lower[2] >= minimum_z)

        in_source, in_target = inside(source, 0.0), inside(target, 0.001)
        in_target &= ~in_source
        outside = ~(in_source | in_target)
        ignored = scattered_mask(points[outside, :2], 0.006 if language else 0.0065, 12 if language else 7)
        ignored_count = int(ignored.sum())
        effective = len(points) - ignored_count
        residual = int(in_source.sum())
        transferred = effective - residual
        fraction = float(in_target.sum() / transferred) if transferred > 0 else 0.0
        ready = (
            ignored_count / len(points) <= 0.2
            and effective > 0
            and transferred > 0
            and residual / effective <= (0.1 if language else 0.15)
            and fraction >= (0.95 if language else 0.97)
        )
        return bool(ready), {
            "transferred_fraction": fraction,
            "residual_particles": residual,
            "ignored_scattered_particles": ignored_count,
            "particle_count": len(points),
        }

    def _pour_liquid_into_cup(self, observation):
        ready, details = self._fluid_ready(observation, "water", "bottle", "cup", language=False)
        upright = axis_up(observation["objects"]["bottle"], 30)
        rising = upright and not self.previous_upright.get("bottle", False)
        self.previous_upright["bottle"] = upright
        if rising and ready:
            self.stage = 1
        success = self.stage == 1
        return success, float(success), {**details, "upright_trigger_recorded": success}

    def _pour_by_language(self, observation):
        sequence, ready, details, rising = self.context.sequence, [], [], []
        for source, target in sequence:
            source_label, target_label = "bottle_" + source, "bowl_" + target
            done, evidence = self._fluid_ready(observation, source, source_label, target_label, language=True)
            ready.append(done)
            details.append(evidence)
            upright = axis_up(observation["objects"][source_label], 30)
            rising.append(upright and not self.previous_upright.get(source_label, False))
            self.previous_upright[source_label] = upright
        target_home = [
            np.all(np.abs(np.asarray(p)[:3] - np.asarray(o)[:3]) <= 0.15) and quaternion_distance(p[3:], o[3:]) <= 20
            for p, o in zip(observation["endposes"], observation["origin_endposes"], strict=True)
        ]
        any_home = any(target_home)
        home_rising = any_home and not getattr(self, "previous_any_home", False)
        self.previous_any_home = any_home
        if home_rising:
            if (not ready[0] and (ready[1] or ready[2])) or (not ready[1] and ready[2]):
                self.violation = "A later liquid was completed before the earlier liquid at the official home trigger"
            tier = (
                100
                if all(ready)
                else 50
                if ready[:2] == [True, True] and not ready[2]
                else 20
                if ready == [True, False, False]
                else 0
            )
            self.best_partial_score = max(self.best_partial_score, tier / 100.0)
        if self.stage < 3 and rising[self.stage] and ready[self.stage]:
            self.stage += 1
        success = self.stage == 3 and self.violation is None
        score = self.best_partial_score if success or self.best_partial_score < 1 else 0.5
        return (
            success,
            score,
            {
                "sequence": [list(pair) for pair in sequence],
                "completed_pours": self.stage,
                "fluid_ready": ready,
                "fluid_evidence": details,
            },
        )
