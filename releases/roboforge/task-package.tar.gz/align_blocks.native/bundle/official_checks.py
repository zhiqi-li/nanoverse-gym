"""Behavioral CPU contracts for the candidate package's official grading rules."""

import ast
import json
import sys
from copy import deepcopy
from importlib.abc import MetaPathFinder
from importlib.machinery import PathFinder, SourceFileLoader
from pathlib import Path

import numpy as np
import yaml
from official_scoring import OfficialRubric, home, rotation


def robot_frame():
    origin = [[-0.3, -0.4, 1.0, 1.0, 0.0, 0.0, 0.0], [0.3, -0.4, 1.0, 1.0, 0.0, 0.0, 0.0]]
    return {
        "endposes": deepcopy(origin),
        "origin_endposes": origin,
        "gripper_open_ratios": [1.0, 1.0],
        "all_joint_positions": np.zeros((2, 8)),
        "support_endposes": [[0.0, 0.4, 1.0, 1.0, 0.0, 0.0, 0.0]],
        "support_origin_endposes": [[0.0, 0.4, 1.0, 1.0, 0.0, 0.0, 0.0]],
    }


def matrix_quaternion(matrix):
    r = np.asarray(matrix)
    k = np.array(
        [
            [r[0, 0] - r[1, 1] - r[2, 2], r[1, 0] + r[0, 1], r[2, 0] + r[0, 2], r[2, 1] - r[1, 2]],
            [r[1, 0] + r[0, 1], r[1, 1] - r[0, 0] - r[2, 2], r[2, 1] + r[1, 2], r[0, 2] - r[2, 0]],
            [r[2, 0] + r[0, 2], r[2, 1] + r[1, 2], r[2, 2] - r[0, 0] - r[1, 1], r[1, 0] - r[0, 1]],
            [r[2, 1] - r[1, 2], r[0, 2] - r[2, 0], r[1, 0] - r[0, 1], np.trace(r)],
        ]
    )
    _, vectors = np.linalg.eigh(k)
    q = vectors[:, -1]
    return [q[3], q[0], q[1], q[2]]


def data_source(source, filename):
    """Load real sampling/context definitions; exclude simulator imports/classes."""
    tree = ast.parse(source, filename=filename)
    selected = []
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            module = node.module or ""
            if module.split(".")[0] in {"env", "pxr", "torch", "omegaconf", "isaacsim", "isaaclab"} or module.endswith(
                ("_support", "_contacts", "_opponent", "_appearance", "_initialization")
            ):
                continue
        if isinstance(node, ast.Import) and any(n.name in {"torch", "pxr"} for n in node.names):
            continue
        if isinstance(node, ast.ClassDef) and node.bases:
            continue
        if isinstance(node, ast.If):
            continue
        selected.append(node)
    return compile(ast.Module(body=selected, type_ignores=[]), filename, "exec")


def candidate(bundle, spec, layout_id=0):
    """Build the actual authored task context and scorer from a retained layout."""
    bundle = Path(bundle).resolve()
    config = yaml.load((bundle / "task_config.yaml").read_text(), Loader=yaml.CSafeLoader)
    declaration = json.loads((bundle / "native_task.json").read_text())
    selected = declaration["layouts"][layout_id]
    layout = json.loads((bundle / selected["path"]).read_text())
    initial = {
        item["label"]: {
            "position": deepcopy(item["default_pos"]),
            "orientation": deepcopy(item["default_ori"]),
            "linear_velocity": [0.0, 0.0, 0.0],
            "angular_velocity": [0.0, 0.0, 0.0],
        }
        for kind in ("Rigid", "Geometry", "Articulation")
        for items in layout.get(kind, {}).values()
        for item in items
        if "label" in item
    }
    assemblies = []
    for category, records in layout.get("Dynamic", {}).items():
        for record in records:
            path = bundle / "assets/native/Dynamic" / category / f"{record['category_idx']:05d}" / "metadata.json"
            assembly = json.loads(path.read_text())
            assemblies.append(assembly)
            root_position, root_orientation = record["default_pos"], record["default_ori"]
            if "links" not in assembly:
                initial[record["label"]] = {
                    "position": deepcopy(root_position),
                    "orientation": deepcopy(root_orientation),
                    "linear_velocity": [0.0, 0.0, 0.0],
                    "angular_velocity": [0.0, 0.0, 0.0],
                }
            for label, link in assembly.get("links", {}).items():
                aw, ax, ay, az = root_orientation
                bw, bx, by, bz = link["orientation_wxyz"]
                orientation = [
                    aw * bw - ax * bx - ay * by - az * bz,
                    aw * bx + ax * bw + ay * bz - az * by,
                    aw * by - ax * bz + ay * bw + az * bx,
                    aw * bz + ax * by - ay * bx + az * bw,
                ]
                initial[label] = {
                    "position": (
                        np.asarray(root_position) + rotation(root_orientation) @ np.asarray(link["position"])
                    ).tolist(),
                    "orientation": orientation,
                    "linear_velocity": [0.0, 0.0, 0.0],
                    "angular_velocity": [0.0, 0.0, 0.0],
                }
    tree = ast.parse((bundle / "task.py").read_text())
    names = {"Rubric", "StackRubric", "CoverSequence"}
    calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in names
    ]
    if len(calls) != 1:
        raise ValueError("Expected one actual sampled task context")
    call = calls[0]
    field = ast.unparse(call.args[1])
    if spec["name"].startswith("classify_objects"):
        metadata = deepcopy(config.get("container_metadata", {}))
        for asset, definition in spec["official_scoring"]["asset_geometry"].items():
            metadata.setdefault(asset, {}).update(definition)
    elif field == "None":
        metadata = None
    elif field == "self.link_metadata":
        metadata = deepcopy(assemblies[0]["link_metadata"])
    elif field.startswith("self."):
        metadata = deepcopy(config[field.removeprefix("self.")])
    elif spec["name"] == "fold_clothes":
        metadata = {"_cloths": {"shirt": deepcopy(config["cloth_metadata"])}}
    else:
        raise ValueError("Unexpected task context metadata expression: " + field)

    class PureLoader(SourceFileLoader):
        def get_code(self, fullname):
            return data_source(self.get_data(self.path).decode(), self.path)

    class PureImports(MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            found = PathFinder.find_spec(fullname, path)
            if (
                found is not None
                and found.origin
                and Path(found.origin).resolve().is_relative_to(bundle)
                and fullname not in {"official_scoring", "official_checks"}
                and isinstance(found.loader, SourceFileLoader)
            ):
                found.loader = PureLoader(fullname, found.origin)
                return found
            return None

    finder = PureImports()
    saved_path = list(sys.path)
    roots = {p.stem for p in bundle.glob("*.py")} | {p.name for p in bundle.iterdir() if p.is_dir()}
    saved = {
        name: module
        for name, module in sys.modules.items()
        if name.split(".")[0] in roots and name not in {"official_scoring", "official_checks"}
    }
    for name in saved:
        sys.modules.pop(name)
    sys.path.insert(0, str(bundle))
    sys.meta_path.insert(0, finder)
    scope = {"__name__": "_official_candidate_data", "__file__": str(bundle / "task.py")}
    try:
        exec(data_source((bundle / "task.py").read_text(), str(bundle / "task.py")), scope)
        args = [spec, metadata, selected["seed"], deepcopy(initial)]
        if len(call.args) == 5:
            args.append(None)
        context = scope[call.func.id](*args)
        rubric = OfficialRubric(context, spec=spec, metadata=metadata, seed=selected["seed"], initial=deepcopy(initial))
        rubric.episode_data = {}
        if spec["name"] == "make_kong":
            rubric.episode_data["episode"] = scope["episode"](selected["seed"])
        if spec["name"] == "imitate_sorting_sequence":
            rubric.episode_data["demo_order"] = scope["demo_order"](selected["seed"])
        frame = {**robot_frame(), "objects": initial}
        if spec["name"] == "fold_clothes":
            frame["garment_orientation"] = config["cloth_poses"][str(selected["seed"])]["orientation_wxyz"]
        return rubric, frame
    finally:
        sys.path[:] = saved_path
        sys.meta_path.remove(finder)
        for name in list(sys.modules):
            if name.split(".")[0] in roots and name not in {"official_scoring", "official_checks"}:
                sys.modules.pop(name)
        sys.modules.update(saved)


def positive_episode(rubric, initial):
    """Construct goal and process counterexamples; these are not robot rollouts."""
    frame = deepcopy(initial)
    frames = [deepcopy(frame)]
    states, task, metadata = frame["objects"], rubric.task, rubric.metadata
    critical = None

    def append():
        frames.append(deepcopy(frame))

    def set_pose(label, position, quaternion=(1.0, 0.0, 0.0, 0.0)):
        states[label]["position"] = list(map(float, position))
        states[label]["orientation"] = list(map(float, quaternion))

    def on(label, reference, point, quaternion=None):
        reference_state = states[reference]
        position = np.asarray(reference_state["position"]) + rotation(reference_state["orientation"]) @ np.asarray(
            point
        )
        set_pose(label, position, quaternion or reference_state["orientation"])

    if task == "align_blocks":
        labels = rubric.context.labels
        for index, label in enumerate(labels):
            set_pose(label, [index * 0.05 - 0.05, -0.1, states[label]["position"][2]])
        critical = labels[0]
    elif task in {"stack_blocks", "stack_blocks_by_language", "stack_bowls"}:
        labels = rubric.context.order if task == "stack_blocks_by_language" else list(rubric.spec["objects"])
        base_z = min(states[label]["position"][2] for label in labels)
        for index, label in enumerate(labels):
            set_pose(label, [0.0, -0.1, base_z + index * (0.012 if task == "stack_bowls" else 0.036)])
        if task == "stack_bowls":
            angle = np.deg2rad(29) / 2
            states[labels[-1]]["orientation"] = [float(np.cos(angle)), float(np.sin(angle)), 0.0, 0.0]
            states[labels[-1]]["position"][0] = 0.02
        critical = labels[0]
    elif task == "general_pickup":
        critical = rubric.context.target
        states[critical]["position"][2] += 0.101
        states[critical]["linear_velocity"] = [0.12, 0.0, 0.0]
    elif task == "arrange_largest_number":
        for index, digit in enumerate(rubric.context.digits):
            label = f"digit_{digit}"
            point = np.asarray(states[f"pad_{index}"]["position"]) + [0.012, 0.0, 0.009]
            set_pose(label, point)
        critical = f"digit_{rubric.context.digits[0]}"
    elif task == "solve_equation":
        critical = rubric.context.label
        set_pose(critical, np.asarray(states[rubric.context.pad]["position"]) + [0.012, 0.0, 0.009])
    elif task == "sort_nesting_dolls_by_size":
        for index, label in enumerate(rubric.context.labels):
            set_pose(label, [index * 0.065 - 0.13, -0.1 + 0.005 * index, states[label]["position"][2]])
        critical = rubric.context.labels[0]
    elif task.startswith("classify_objects"):
        for category, labels in rubric.spec["classification"]["categories"].items():
            basket = f"basket_{rubric.context.assignment[category]}"
            for index, label in enumerate(labels):
                on(label, basket, [(index - 0.5) * 0.035, 0.0, 0.017])
        critical = next(iter(rubric.spec["classification"]["categories"].values()))[0]
    elif task == "deposit_coin":
        critical = "coin"
        on("coin", "bank", [0.0, 0.0, 0.08])
    elif task == "fasten_screws":
        for index in range(3):
            set_pose(f"bolt_{index}", [index * 0.07 - 0.07, -0.1, 0.78])
            on(f"nut_{index}", f"bolt_{index}", [0.0, 0.0, -0.002])
        critical = "nut_0"
    elif task == "fill_egg_holder":
        for index, cup in enumerate(metadata["holder"]["cups"]):
            on(f"egg_{index}", "holder", np.asarray(cup["center"]) * [1.0, 1.0, 0.0] + [0.0, 0.0, 0.027])
        on("lid", "holder", rubric.spec["joints"]["lid_hinge"]["anchor0"])
        critical = "egg_0"
    elif task == "fill_pen_holder":
        labels = [label for label in rubric.spec["objects"] if label != "holder"]
        for index, label in enumerate(labels):
            on(label, "holder", [(-0.009, 0.009)[index % 2], (-0.009, 0.009)[index // 2], 0.005])
        critical = labels[0]
    elif task == "insert_tubes":
        for index in range(3):
            on(f"tube_{index}", "rack", [*metadata["rack"]["holes"][index * 2], 0.005])
        critical = "tube_0"
    elif task == "plug_in_charger":
        critical = "charger"
        on("charger", "strip", [*metadata["strip"]["sockets"][1], 0.0115])
    elif task == "put_bottles_into_dustbin":
        labels = [label for label in rubric.spec["objects"] if label != "bin"]
        for index, label in enumerate(labels):
            on(label, "bin", [(index % 2 - 0.5) * 0.025, (index // 2 - 0.5) * 0.025, 0.008])
        critical = labels[0]
    elif task == "push_t":
        critical = "block"
        states["block"] = deepcopy(states["target"])
        states["block"]["position"][0] += 0.005
    elif task == "swap_t":
        for label, target in rubric.context.targets.items():
            states[label] = deepcopy(target)
            states[label]["position"][0] += 0.012
        critical = rubric.context.labels[0]
    elif task in {"match_and_pick_from_conveyor", "pick_from_conveyor_by_image"}:
        critical = rubric.context.plan["target_label"]
        if task == "match_and_pick_from_conveyor":
            states[critical]["position"][2] += 0.101
        else:
            states["basket"]["position"][2] += 0.13
            body_min = rubric._vertices(critical)[:, 2].min()
            basket_min = rubric._vertices("basket")[:, 2].min()
            on(critical, "basket", [0.0, 0.0, basket_min - body_min + 0.007])
    elif task == "pour_balls_into_vase":
        for index in range(7):
            on(f"ball_{index}", "vase", [(index % 3 - 1) * 0.009, (index // 3 - 1) * 0.009, 0.016])
        critical = "ball_0"
    elif task == "play_stacking_toy":
        for group, labels in rubric.context.groups.items():
            for index, label in enumerate(sorted(labels)):
                on(label, "base", [*rubric.spec["goal"]["peg_centers"][group], 0.015 + index * 0.01])
        critical = next(iter(rubric.context.groups.values()))[0]
    elif task == "pack_objects_into_box":
        set_pose("box", states["box"]["position"])
        for index, label in enumerate(("hammer", "driver", "tape", "slipper")):
            on(label, "box", [(index % 2 - 0.5) * 0.095, (index // 2 - 0.5) * 0.085, 0.025], [0.0, 0.0, 0.0, 1.0])
        critical = "hammer"
    elif task == "build_tower":
        heights = {
            "lower_left": 0.795,
            "lower_right": 0.795,
            "lower_board": 0.827,
            "middle_left": 0.854,
            "middle_right": 0.854,
            "middle_board": 0.881,
            "upper_support": 0.912,
            "top_board": 0.937,
        }
        for label, height in heights.items():
            set_pose(
                label,
                [
                    (-0.055 if label.endswith("left") else 0.055) if label.endswith(("left", "right")) else 0.0,
                    -0.1,
                    height,
                ],
            )
        critical = "top_board"
    elif task == "hang_mugs":
        for index in range(3):
            hook = metadata["rack"]["hooks"][index + 2]
            axis = np.asarray(hook["axis"])
            x = np.cross([0.0, 0.0, 1.0], axis)
            x /= np.linalg.norm(x)
            y = -axis
            z = np.cross(x, y)
            matrix = np.column_stack([x, y, z])
            # A standard matrix-to-quaternion conversion for fixture poses.
            quat = matrix_quaternion(rotation(states["rack"]["orientation"]) @ matrix)
            handle = np.asarray(states["rack"]["position"]) + rotation(states["rack"]["orientation"]) @ np.asarray(
                hook["end"]
            )
            position = handle - rotation(quat) @ np.asarray(metadata["mug"]["handle"]["center"])
            set_pose(f"mug_{index}", position, quat)
        critical = "mug_0"
    elif task == "sweep_blocks":
        states["broom"]["position"][0] = states["dustpan"]["position"][0] + 0.2
        for index in range(3):
            on(f"block_{index}", "dustpan", [index * 0.018 - 0.018, 0.0, 0.012])
        critical = "block_0"
    elif task == "cover_blocks":
        colors = ["red", "green", "blue"]
        order = sorted(colors, key=lambda label: states[label]["position"][0])
        for index, color in enumerate(order):
            on(f"cup_{index}", color, [0.0, 0.0, -0.01])
            append()
        for color in colors:
            index = order.index(color)
            states[f"cup_{index}"] = deepcopy(initial["objects"][f"cup_{index}"])
            append()
        critical = "red"
    elif task == "press_by_number":
        for name, count in (
            ("0", rubric.context.targets[0]),
            ("confirm", 1),
            ("1", rubric.context.targets[1]),
            ("confirm", 1),
        ):
            for _ in range(count):
                states["cap_" + name]["position"][2] -= 0.003
                append()
                states["cap_" + name]["position"][2] += 0.003
                append()
        critical = "cap_confirm"
    elif task == "swap_blocks":
        origins, empty = rubric.context.origins, rubric.context.empty
        targets = [(0, empty), (1, origins[0]), (0, origins[1])]
        for block, mat in targets:
            on(f"block_{block}", f"mat_{mat}", [0.0, 0.0, 0.019])
            append()
            states["button_cap"]["position"][2] -= 0.003
            append()
            states["button_cap"]["position"][2] += 0.003
            append()
        critical = "block_0"
    elif task == "imitate_sorting_sequence":
        order = rubric.episode_data["demo_order"]
        for side in ("demo", "player"):
            for index, kind in enumerate(order):
                on(side + "_" + kind, side + "_bin", [(index % 3 - 1) * 0.05, (index // 3 - 0.5) * 0.055, 0.012])
                append()
        critical = "player_" + order[0]
    elif task == "play_tic_tac_toe":
        labels = [f"player_{i}" for i in range(5)] + [f"opponent_{i}" for i in range(4)]
        spacing = metadata["board"]["cell_spacing"]
        for index, label in enumerate(labels):
            on(label, "board", [(index % 3 - 1) * spacing, (index // 3 - 1) * spacing, 0.016])
        critical = "player_0"
    elif task == "make_toast":
        for index in range(2):
            on(f"bread_{index}", "toaster", metadata["toaster"]["slots"][index]["center"])
        for index in range(2, 4):
            on(f"bread_{index}", "rack", metadata["rack"]["bread_slots"][index]["center"])
        on("lever", "toaster", np.asarray(rubric.spec["joints"]["lever_slide"]["anchor0"]) - [0.0, 0.0, 0.022])
        critical = "bread_0"
    elif task == "organize_table":
        for label, fixture, point in (
            ("keyboard", "keyboard_frame", "keyboard_origin"),
            ("mouse", "mousepad", "mouse_origin"),
            ("figurine", "figurine_stand", "figurine_origin"),
            ("alarm_clock", "cabinet", "clock_origin"),
        ):
            on(label, fixture, metadata[fixture][point], [1.0, 0.0, 0.0, 0.0])
        critical = "keyboard"
    elif task == "store_tools_in_toolbox":
        for label, slot in metadata["toolbox"]["slots"].items():
            yaw = np.deg2rad(slot["yaw_deg"]) / 2
            # Box yaw is below three degrees in every retained layout.
            on(label, "toolbox", slot["position"], [np.cos(yaw), 0.0, 0.0, np.sin(yaw)])
        on("lid", "toolbox", rubric.spec["joints"]["cover_hinge"]["anchor0"])
        critical = "hammer"
    elif task == "store_laptop_and_headphones":
        on("headphones", "headphone_stand", metadata["headphone_stand"]["headphone_origin"])
        roll = np.pi / 4
        on(
            "laptop_base",
            "vertical_rack",
            metadata["vertical_rack"]["laptop_base_origin"],
            [np.cos(roll), np.sin(roll), 0.0, 0.0],
        )
        on("laptop_lid", "laptop_base", rubric.spec["joints"]["laptop_hinge"]["anchor0"])
        critical = "headphones"
    elif task == "insert_key":
        angle = np.deg2rad(60) / 2
        on("rotor", "housing", [0.0, 0.0, 0.0], [np.cos(angle), 0.0, 0.0, np.sin(angle)])
        on("key", "rotor", [0.0, 0.0, metadata["rotor"]["slot_top"] - 0.026])
        critical = "key"
    elif task == "play_xylophone":
        for index in range(4):
            key = metadata["instrument"]["keys"][index]
            on(
                "mallet",
                "instrument",
                np.asarray(key["center"]) + [0.0, 0.0, 0.02] - np.asarray(metadata["mallet"]["head_center"]),
            )
            append()
            states["mallet"]["position"][2] += 0.026
            append()
        critical = "mallet"
    elif task == "make_kong":
        critical = rubric.episode_data["episode"]["discard_label"]
        identity = rubric.episode_data["episode"]["identity"]
        states[critical]["position"][1] -= 0.15
        for index in range(3):
            label = f"player_{identity}_{index}"
            states[label]["orientation"] = [np.sqrt(0.5), -np.sqrt(0.5), 0.0, 0.0]
        # The official first-pose quaternion mapped to the reconstructed frame.
        states[critical]["orientation"] = [0.5, 0.5, 0.5, 0.5]
        append()
        on(critical, "marker", [0.0, 0.0, 0.002])
    elif task == "fold_clothes":
        count = metadata["_cloths"]["shirt"]["vertex_count"]
        positions = np.zeros((count, 3)) + [0.0, 0.0, 0.78]
        landmarks = {
            "left_cuff": [0.02, 0.0, 0.78],
            "right_chest": [0.02, 0.0, 0.78],
            "right_cuff": [-0.02, 0.0, 0.78],
            "left_chest": [-0.02, 0.0, 0.78],
            "left_hem": [-0.06, 0.03, 0.78],
            "right_hem": [0.06, 0.03, 0.78],
            "left_shoulder": [-0.06, 0.07, 0.78],
            "right_shoulder": [0.06, 0.07, 0.78],
        }
        for name, indices in metadata["_cloths"]["shirt"]["landmarks"].items():
            if name in landmarks:
                positions[indices] = landmarks[name]
        frame["cloths"] = {
            "shirt": {
                "positions": positions,
                "velocities": np.zeros_like(positions),
                "measurement": "physx_particle_cloth_tensor",
            }
        }
        frames[0] = deepcopy(frame)
        frames[0]["cloths"]["shirt"]["positions"][metadata["_cloths"]["shirt"]["landmarks"]["left_cuff"], 0] += 0.4
    elif task in {"pour_by_language", "pour_liquid_into_cup"}:
        frame["liquids"] = {}
        backend = {
            "prim_type": "Points",
            "particle_smoothing": False,
            "particle_anisotropy": False,
            "update_particles_to_usd": True,
            "gpu_readback_suppressed": False,
            "coordinates": "world_metres",
        }
        sequence = rubric.context.sequence if task == "pour_by_language" else [("water", "cup")]
        for source, target in sequence:
            count = rubric.context.counts[source] if task == "pour_by_language" else rubric.context.expected_count
            label = "bottle_" + source if task == "pour_by_language" else "bottle"
            local = np.zeros((count, 3)) + [0.0, 0.0, 0.03]
            points = local @ rotation(states[label]["orientation"]).T + states[label]["position"]
            frame["liquids"][source] = {
                "positions": points,
                "measurement": "physx_unsmoothed_usd_points",
                "backend": deepcopy(backend),
            }
        frames[0] = deepcopy(frame)
        for source, target in sequence:
            target_label = "bowl_" + target if task == "pour_by_language" else target
            source_label = "bottle_" + source if task == "pour_by_language" else "bottle"
            states[source_label]["orientation"] = [np.sqrt(0.5), np.sqrt(0.5), 0.0, 0.0]
            for pose, origin in zip(frame["endposes"], frame["origin_endposes"], strict=True):
                pose[0] = origin[0] + 0.2
            append()
            frame["liquids"][source]["positions"] = np.zeros_like(frame["liquids"][source]["positions"]) + (
                np.asarray(states[target_label]["position"]) + [0.0, 0.0, 0.025]
            )
            states[source_label]["orientation"] = [1.0, 0.0, 0.0, 0.0]
            frame["endposes"] = deepcopy(frame["origin_endposes"])
            append()
        critical = "liquids"
    else:
        raise ValueError("Missing official semantic fixture for " + task)
    append()
    append()
    return frames, critical


def denied_episode(rubric, frames, critical):
    denied = deepcopy(frames)
    for frame in denied:
        if rubric.task in {"general_pickup", "match_and_pick_from_conveyor"}:
            frame["objects"][critical]["position"][2] = rubric.initial[critical]["position"][2] + 0.05
        elif rubric.task == "align_blocks":
            frame["objects"][critical]["position"][1] += 0.05
        elif rubric.task == "fold_clothes":
            indices = rubric.metadata["_cloths"]["shirt"]["landmarks"]["left_cuff"]
            frame["cloths"]["shirt"]["positions"][indices, 0] += 0.4
        elif critical == "liquids":
            source = rubric.context.sequence[0][0] if rubric.task == "pour_by_language" else "water"
            frame["liquids"][source]["positions"][:, 0] += 1.0
        elif rubric.task == "press_by_number":
            # A held/released confirmation cap without its physical press edges
            # cannot substitute for the required two acknowledgments.
            frame["objects"][critical]["position"] = deepcopy(rubric.initial[critical]["position"])
        else:
            frame["objects"][critical]["position"][0] += 1.0
    return denied


def evaluate(rubric, frames):
    fresh = OfficialRubric(
        rubric.context, spec=rubric.spec, metadata=rubric.metadata, seed=rubric.seed, initial=deepcopy(rubric.initial)
    )
    reports = [fresh.step(frame, 0.004) for frame in frames]
    return reports


def check(bundle, spec):
    def row(name, passed, requirement, evidence):
        return {"name": name, "passed": bool(passed), "requirements": [requirement], "evidence": evidence}

    source = ast.parse((bundle / "task.py").read_text())
    wired = any(
        isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "OfficialRubric"
        for node in ast.walk(source)
    )
    direct = [
        node
        for node in ast.walk(source)
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Attribute) and target.attr.endswith("_complete") for target in node.targets)
        and isinstance(node.value, ast.Call)
        and ast.unparse(node.value).startswith("bool(self.")
        and "['success']" in ast.unparse(node.value)
    ]
    rows = [
        row(
            "native_uses_reviewed_rules",
            wired and len(direct) == 1,
            "native_wiring",
            {"official_constructor": wired, "direct_completion_updates": len(direct)},
        )
    ]
    observation = robot_frame()
    observation["endposes"][0][0] += 0.149
    rows.append(
        row(
            "tcp_near_origin_allowed",
            home(observation),
            "official_home",
            {"tcp_offset_m": 0.149, "additional_joint_zero_gate": False},
        )
    )
    observation["endposes"][0][0] += 0.002
    rows.append(row("tcp_outside_origin_denied", not home(observation), "official_home", {"tcp_offset_m": 0.151}))
    for layout_id in range(8):
        rubric, initial_frame = candidate(bundle, spec, layout_id)
        frames, critical = positive_episode(rubric, initial_frame)
        positive = evaluate(rubric, frames)
        negative = evaluate(rubric, denied_episode(rubric, frames, critical))
        rows.extend(
            [
                row(
                    f"layout_{layout_id}_initial_denied",
                    not positive[0]["success"],
                    "official_goal",
                    {"seed": rubric.seed, "native_success": positive[0]["success"]},
                ),
                row(
                    f"layout_{layout_id}_official_goal_allowed",
                    positive[-1]["success"],
                    "official_goal",
                    {
                        "seed": rubric.seed,
                        "native_score": positive[-1]["score"],
                        "constructed_frames": len(frames),
                        "scope": "Constructed CPU task-state sequence; no simulator or robot episode",
                    },
                ),
                row(
                    f"layout_{layout_id}_wrong_goal_denied",
                    not any(report["success"] for report in negative),
                    "official_goal",
                    {
                        "seed": rubric.seed,
                        "final_native_score": negative[-1]["score"],
                        "counterexample_target": critical,
                    },
                ),
            ]
        )
    if spec["name"] != "stack_bowls":
        return rows
    initial = {
        f"bowl_{i}": {
            "position": [i * 0.18, 0.0, 0.766],
            "orientation": [1.0, 0.0, 0.0, 0.0],
            "linear_velocity": [0.0, 0.0, 0.0],
            "angular_velocity": [0.0, 0.0, 0.0],
        }
        for i in range(3)
    }

    def scorer():
        return OfficialRubric(None, spec=spec, metadata=None, seed=0, initial=deepcopy(initial))

    observation = {**robot_frame(), "objects": deepcopy(initial)}
    result = scorer().step(observation, 0.004)
    rows.append(row("separate_bowls_denied", not result["success"], "official_goal", {"score": result["score"]}))
    observation["objects"]["bowl_0"]["position"] = [0.0, 0.0, 0.766]
    observation["objects"]["bowl_1"]["position"] = [0.0, 0.0, 0.774]
    observation["objects"]["bowl_2"]["position"] = [0.01998, 0.0, 0.8017]
    angle = np.deg2rad(29.38) / 2
    observation["objects"]["bowl_2"]["orientation"] = [np.cos(angle), np.sin(angle), 0.0, 0.0]
    result = scorer().step(observation, 0.004)
    rows.append(
        row(
            "official_loose_stack_allowed",
            result["success"] and result["score"] == 1.0,
            "official_goal",
            {
                "xy_offset_m": 0.01998,
                "upper_gap_m": 0.0277,
                "upper_tilt_deg": 29.38,
                "native_score": result["score"],
                "additional_hold_seconds": 0,
            },
        )
    )
    observation["objects"]["bowl_2"]["position"][0] = 0.0401
    result = scorer().step(observation, 0.004)
    rows.append(row("outside_official_stack_denied", not result["success"], "official_goal", {"xy_offset_m": 0.0401}))
    observation["objects"]["bowl_2"]["position"][0] = 0.01
    observation["objects"]["bowl_2"]["position"][2] = 0.777
    result = scorer().step(observation, 0.004)
    rows.append(row("insufficient_stack_height_denied", not result["success"], "official_goal", {"z_gap_m": 0.003}))
    return rows
