"""Native alignment with unchanged physics-rate contact provenance and rubric."""
from official_scoring import OfficialRubric, robot_observation
import math
import numpy as np
from align_blocks_contacts import NativePairContacts
from align_blocks_scene_support import install_cpu_collider_cleanup
from env.environment.task_env import TaskEnv
from env.reward_manager.reward_manager import RewardManager
from omegaconf import OmegaConf

def array(value):
    if hasattr(value, 'detach'):
        value = value.detach().cpu().numpy()
    return np.asarray(value, dtype=float).reshape(-1).copy()

def rotation_matrix(quaternion):
    q = np.asarray(quaternion, dtype=float)
    norm = np.linalg.norm(q)
    if not np.isfinite(norm) or norm < 1e-10:
        raise ValueError('A pose needs a finite, nonzero quaternion')
    w, x, y, z = q / norm
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)], [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)], [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])

def row_metrics(states):
    positions = np.asarray([state['position'] for state in states])
    centered = positions[:, :2] - positions[:, :2].mean(axis=0)
    _, vectors = np.linalg.eigh(centered.T @ centered)
    axis = vectors[:, -1]
    if axis[0] < 0:
        axis = -axis
    normal = np.array([-axis[1], axis[0]])
    angle = math.atan2(axis[1], axis[0])
    errors, tilts = ([], [])
    for state in states:
        rotation = rotation_matrix(state['orientation'])
        yaw = math.atan2(rotation[1, 0], rotation[0, 0])
        errors.append(abs((yaw - angle + math.pi / 4) % (math.pi / 2) - math.pi / 4))
        tilts.append(math.acos(float(np.clip(rotation[2, 2], -1, 1))))
    return {'row_error_m': float(np.max(np.abs(centered @ normal))), 'parallel_error_deg': math.degrees(max(errors)), 'tilt_deg': math.degrees(max(tilts)), 'axis_xy': axis.tolist(), 'minimum_spacing_m': float(np.diff(np.sort(centered @ axis)).min())}

class Rubric:

    def __init__(self, spec, metadata, seed, initial_state):
        self.goal, self.scoring = (spec['goal'], spec['scoring'])
        self.labels = [label for label, item in spec['objects'].items() if item['asset'] == 'block']
        self.width = metadata['block']['width']
        self.grasp = np.asarray(metadata['set_square']['grasp']['center'])
        self.initial_z = {name: initial_state[name]['position'][2] for name in self.labels}
        self.tool_initial_z = initial_state['set_square']['position'][2]
        initial_tool = initial_state['set_square']
        self.grasp_initial_z = (np.asarray(initial_tool['position']) + rotation_matrix(initial_tool['orientation']) @ self.grasp)[2]
        self.maximum_grasp_lift = 0.0
        self.previous_positions = {name: np.asarray(initial_state[name]['position'])[:2].copy() for name in self.labels}
        self.contact_start, self.contact_last = ({}, {})
        self.push_distances = {name: 0.0 for name in self.labels}
        self.maximum_lifts = {name: 0.0 for name in self.labels}
        self.acquired, self.violation, self.home = (False, False, None)
        self.time, self.stable = (0.0, 0.0)

    def step(self, observation, dt):
        if not np.isfinite(dt) or dt < 0:
            raise ValueError('Invalid physics observation interval')
        if 'contacts' not in observation or len(observation.get('contact_body_pair', [])) != 2:
            raise ValueError('Alignment requires measured tool-to-block contact observations')
        self.time += dt
        states = observation['objects']
        joints = np.asarray(observation['all_joint_positions'], dtype=float)[:, :6]
        if self.home is None:
            self.home = joints.copy()
        tool = states['set_square']
        grasp = np.asarray(tool['position']) + rotation_matrix(tool['orientation']) @ self.grasp
        held = any((np.linalg.norm(np.asarray(tcp) - grasp) < self.goal['grasp_position_tolerance'] and gap < self.goal['maximum_gripper_gap'] for tcp, gap in zip(observation['grippers'], observation['gripper_gaps'], strict=True)))
        grasp_lift = float(grasp[2] - self.grasp_initial_z)
        if held:
            self.maximum_grasp_lift = max(self.maximum_grasp_lift, grasp_lift)
        pickup = min(1.0, self.maximum_grasp_lift / self.goal['minimum_grasp_lift'])
        self.acquired |= bool(held and grasp_lift + 1e-09 >= self.goal['minimum_grasp_lift'])
        touched = set()
        for contact in observation['contacts']:
            if contact['body_pair'] != observation['contact_body_pair']:
                continue
            if abs(contact['normal_impulse_ns']) < self.goal['minimum_normal_impulse_ns']:
                continue
            if np.linalg.norm(np.asarray(contact['normal_world'])[:2]) < 0.75:
                continue
            point = np.asarray(contact['point_world_m'])
            for name in self.labels:
                state = states[name]
                local = rotation_matrix(state['orientation']).T @ (point - state['position'])
                if np.max(np.abs(local)) <= self.width / 2 + self.goal['contact_point_margin']:
                    touched.add(name)
        for name in self.labels:
            position = np.asarray(states[name]['position'])
            self.maximum_lifts[name] = max(self.maximum_lifts[name], float(position[2] - self.initial_z[name]))
            self.violation |= self.maximum_lifts[name] > self.goal['maximum_lift'] + 1e-09
            if name in touched and held:
                if self.time - self.contact_last.get(name, -1000000.0) > self.goal['recent_contact_seconds']:
                    self.contact_start[name] = self.previous_positions[name].copy()
                self.contact_last[name] = self.time
            if held and self.time - self.contact_last.get(name, -1000000.0) <= self.goal['recent_contact_seconds']:
                displacement = float(np.linalg.norm(position[:2] - self.contact_start[name]))
                self.push_distances[name] = max(self.push_distances[name], displacement)
            self.previous_positions[name] = position[:2].copy()
        metrics = row_metrics([states[name] for name in self.labels])
        push = float(np.mean([min(1.0, value / self.goal['required_push_distance']) for value in self.push_distances.values()]))
        row = float(np.clip(1 - max(0, metrics['row_error_m'] - self.goal['row_tolerance']) / 0.025, 0, 1))
        parallel_excess = max(0, metrics['parallel_error_deg'] - self.goal['parallel_tolerance_deg'])
        parallel = float(np.clip(1 - parallel_excess / 30, 0, 1))
        home_error = float(np.max(np.abs(joints - self.home)))
        home = home_error <= self.goal['home_joint_tolerance']
        released = not held and min(observation['gripper_gaps']) >= self.goal['open_gripper_gap']
        stable_bodies = all((np.linalg.norm(states[name]['linear_velocity']) < self.goal['linear_speed_tolerance'] and np.linalg.norm(states[name]['angular_velocity']) < self.goal['angular_speed_tolerance'] for name in [*self.labels, 'set_square']))
        supported = all((abs(states[name]['position'][2] - self.initial_z[name]) <= self.goal['support_height_tolerance'] for name in self.labels))
        fit = bool(self.acquired and push >= 1 - 1e-09 and (row >= 1 - 1e-09) and (parallel >= 1 - 1e-09) and (metrics['minimum_spacing_m'] >= self.width - 0.002) and (metrics['tilt_deg'] < self.goal['tilt_tolerance_deg']) and (not self.violation) and home and released and stable_bodies and supported)
        self.stable = self.stable + dt if fit else 0.0
        values = {'tool_acquired': pickup, 'indirect_pushes': push, 'straight_row': row * push, 'parallel_faces': parallel * push, 'stable_home': min(1.0, self.stable / self.goal['hold_seconds'])}
        if self.violation:
            values = dict.fromkeys(values, 0.0)
        criteria = {name: {'weight': self.scoring[name]['weight'], 'value': value, 'score': value * self.scoring[name]['weight']} for name, value in values.items()}
        success = bool(fit and self.stable + 1e-08 >= self.goal['hold_seconds'])
        return {'success': success, 'satisfied': success, 'score': sum((c['score'] for c in criteria.values())), 'criteria': criteria, **metrics, 'tool_currently_grasped': bool(held), 'contacted_blocks': sorted(touched), 'push_distances_m': dict(self.push_distances), 'maximum_lifts_m': dict(self.maximum_lifts), 'no_lift_violation': bool(self.violation), 'home_joint_error_rad': home_error, 'released': released, 'supported_on_table': supported, 'stable_seconds': self.stable, 'evaluation_version': 2, 'tool_pickup_recorded': bool(self.acquired), 'grasp_lift_m': grasp_lift, 'maximum_held_grasp_lift_m': self.maximum_grasp_lift, 'required_grasp_lift_m': self.goal['minimum_grasp_lift'], 'tool_origin_lift_m': float(tool['position'][2] - self.tool_initial_z), 'grasp_distances_m': [float(np.linalg.norm(np.asarray(tcp) - grasp)) for tcp in observation['grippers']], 'measured_gripper_gaps_m': list(observation['gripper_gaps']), 'public_score': 100 if success else 0}

class AlignmentReward(RewardManager):

    def init_state(self):
        super().init_state()
        self.env.begin_alignment_episode()

    def call_func_parser(self, function, env_idx):
        if function[0] == 'alignment_complete':
            if env_idx != 0 or function[1]:
                raise ValueError('Unexpected alignment completion arguments')
            return float(self.env.alignment_complete)
        return super().call_func_parser(function, env_idx)

    def get_score(self, reward_lst=None):
        return [100.0 * float(self.env.alignment_report['score'])]

class align_blocks(TaskEnv):

    def __init__(self, config, app, **kwargs):
        settings = OmegaConf.to_container(config.task_env, resolve=True)
        if config.sim.scene.num_envs != 1 or config.sim.dt != 0.004 or config.sim.decimation != 1:
            raise ValueError('Retained contact rules require one environment and 0.004-second physics ticks')
        self.spec = settings['authored_spec']
        self.rubric_metadata = settings['rubric_metadata']
        self.layout_seeds = settings['layout_seeds']
        self.step_lim = settings['max_control_steps']
        self.grading = False
        self.pair_contacts = None
        self.alignment_report = {'score': 0.0}
        self.alignment_complete = False
        self.held_seconds = 0.0
        self.contact_samples = []
        super().__init__(config, app, **kwargs)
        self.reward_manager = AlignmentReward(self.num_envs)

    def _post_setup_scene(self, sim):
        super()._post_setup_scene(sim)
        self.reward_manager.initialize(self)
        install_cpu_collider_cleanup(self.scene_manager)

    def object(self, label):
        manager = self.scene_manager.layout_manager
        instance = manager.get_instance_name(0, label)
        if instance is None:
            raise KeyError(label)
        return manager.get_scene_object(0, instance)

    def body_states(self):
        states = {}
        for label in self.spec['objects']:
            obj = self.object(label)
            position, orientation = obj.get_local_pose()
            states[label] = {'position': array(position), 'orientation': array(orientation), 'linear_velocity': array(obj.get_linear_velocity()), 'angular_velocity': array(obj.get_angular_velocity())}
        return states

    def reset(self, seed=None, options=None):
        if not isinstance(seed, list | tuple) or len(seed) != 1 or type(seed[0]) is not int:
            raise ValueError('Alignment reset requires one native layout ID')
        if not 0 <= seed[0] < len(self.layout_seeds):
            raise ValueError('Unknown alignment layout ID')
        self.grading = False
        self.pair_contacts = None
        self.contact_samples = []
        self.authored_seed = self.layout_seeds[seed[0]]
        self.alignment_report = {'score': 0.0}
        self.alignment_complete = False
        self.held_seconds = 0.0
        self.reward_manager.reset()
        return super().reset(seed=seed, options=options)

    def begin_alignment_episode(self):
        blocks = [str(self.object(f'block_{index}').prim_path) for index in range(3)]
        parents = {path.rsplit('/', 1)[0] for path in blocks}
        if len(parents) != 1:
            raise RuntimeError('Expected all three block actors in one explicit asset category')
        self.pair_contacts = NativePairContacts(str(self.object('set_square').prim_path), parents.pop() + '/.*', name='square_three_blocks', capacity=192, target_paths=blocks)
        self.pair_contacts.initialize()
        self.contact_configuration = {**self.pair_contacts.configuration(), 'current_block_paths': blocks}
        self.alignment_rubric = OfficialRubric(Rubric(self.spec, self.rubric_metadata, self.authored_seed, self.body_states()), spec=self.spec, metadata=self.rubric_metadata, seed=self.authored_seed, initial=self.body_states())
        self.grading = True

    def alignment_observation(self):
        if self.pair_contacts is None:
            raise RuntimeError('Alignment contact readback requires the post-settle episode initialization')
        grippers, gaps, joints = ([], [], [])
        for robot, arm in zip(self.robot_manager.robot_list, self.robot_manager.robot_key, strict=True):
            pose = array(self.robot_manager.get_delta_endpose(robot)[0])
            grippers.append(pose[:3] + rotation_matrix(pose[3:])[:, 0] * robot.gripper_bias)
            gaps.append(float(array(arm.data.joint_pos[0, robot.gripper_joint_indices]).sum()))
            joints.append(array(arm.data.joint_pos[0, robot.arm_joint_indices + robot.gripper_joint_indices]))
        return robot_observation(self, {'objects': self.body_states(), 'grippers': grippers, 'gripper_gaps': gaps, 'all_joint_positions': joints, 'contact_body_pair': list(self.pair_contacts.body_pair), 'contacts': self.pair_contacts.read()})

    def sim_step(self, render=True):
        result = super().sim_step(render=render)
        if self.grading:
            observation = self.alignment_observation()
            self.alignment_report = self.alignment_rubric.step(observation, self.dt)
            step = len(self.contact_samples) + 1
            self.contact_samples.append({'step': step, 'time': step * self.dt, 'observation': observation})
            self.held_seconds = float(self.alignment_report.get('stable_seconds', getattr(self.alignment_rubric, 'elapsed', 0.0)))
            self.alignment_complete = bool(self.alignment_report['success'])
        return result

    def run_reward(self):
        self.reward_manager.check_single_env(0, [('alignment_complete', {})])

    def get_score(self):
        return self.reward_manager.get_score()

    def gen_instruction(self, env_idx=0):
        return [self.spec['instruction']]

    def close(self):
        self.grading = False
        self.pair_contacts = None
        return super().close()
