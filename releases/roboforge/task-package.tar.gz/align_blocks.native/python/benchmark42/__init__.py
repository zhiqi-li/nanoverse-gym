"""Self-contained native task package tools."""
