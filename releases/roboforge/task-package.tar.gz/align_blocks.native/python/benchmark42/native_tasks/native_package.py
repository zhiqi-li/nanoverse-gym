"""Package authored native RoboDojo tasks without replacing their task classes.

This module is shipped with each package and uses only the standard library.
Verification binds content and resource paths; it is not a Python sandbox or a
claim that the task has passed native simulation acceptance.
"""

import ast
import hashlib
import json
import keyword
import math
import re
import shutil
from copy import deepcopy
from pathlib import Path

DECLARATION = "native_task.json"
MANIFEST = "native_package.json"
PROTOCOL = "robodojo_task_v1"
OBJECT_TYPES = ("Rigid", "Dynamic", "Geometry", "Articulation", "Garment", "Fluid")
RUNTIME = "python/benchmark42/native_tasks/native_package.py"
BASE_ASSETS = (
    "Robots", "Background", "Scene", "Room", "Table", "Ground", "Light",
    "Texture", "Textures", "Material", "Materials",
)
DECLARATION_KEYS = {
    "schema_version", "task_id", "task_module", "task_config", "python_files",
    "asset_root", "layouts", "native_config", "config_name", "eval_seed",
    "max_control_steps", "control_dt", "finish_mode",
}


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def _identity(manifest):
    value = {key: item for key, item in manifest.items() if key != "identity_sha256"}
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def _relative(value):
    _require(isinstance(value, str) and value, "Package paths must be nonempty strings")
    path = Path(value)
    _require(not path.is_absolute() and str(path) == value and ".." not in path.parts
             and "\\" not in value and path.parts and path.parts[0] != ".",
             "Use a canonical package-relative path: " + value)
    return path


def _component(value):
    return isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*", value) is not None


def _file(root, relative):
    path = root / _relative(relative)
    _require(path.is_file() and path.resolve() == path, "Missing or aliased source file: " + relative)
    return path


def _directory(value):
    path = Path(value).absolute()
    _require(path.is_dir() and path.resolve() == path, "Use an existing canonical directory: " + str(path))
    return path


def _destination(value, protected):
    path = Path(value).absolute()
    _require(path.resolve() == path and not path.exists()
             and not any(path.is_relative_to(root) for root in protected),
             "Use a fresh canonical destination outside protected inputs")
    return path


def _source_files(root, declaration, *, built):
    files = {DECLARATION, declaration["task_module"], declaration["task_config"], *declaration["python_files"]}
    files.update(declaration.get("data_files", []))
    if built:
        files.update(row["path"] for row in declaration["layouts"])
        assets = root / declaration["asset_root"]
        _require(assets.is_dir() and assets.resolve() == assets, "Missing or aliased native asset root")
        for path in assets.rglob("*"):
            _require(not path.is_symlink(), "Native assets cannot contain aliased files or directories")
            if path.is_file():
                files.add(path.relative_to(root).as_posix())
            else:
                _require(path.is_dir(), "Unsupported native asset filesystem entry")
    return sorted(files)


def _check_layouts(root, declaration):
    assets = root / declaration["asset_root"]
    available = set()
    for kind in assets.iterdir():
        _require(kind.is_dir() and kind.name in OBJECT_TYPES, "Unknown native object type: " + kind.name)
        for category in kind.iterdir():
            _require(category.is_dir() and _component(category.name), "Invalid native asset category")
            for instance in category.iterdir():
                _require(instance.is_dir() and instance.name.isdecimal()
                         and instance.name == f"{int(instance.name):05d}", "Invalid native asset index")
                _require((instance / "object.usd").is_file() or (instance / "object.usdz").is_file(),
                         "Native assets require object.usd or object.usdz: " + str(instance))
                metadata_path = (instance / "metadata.json").relative_to(root).as_posix()
                metadata = json.loads(_file(root, metadata_path).read_text())
                _require(type(metadata) is dict and bool(metadata.get("geometry")),
                         "Native object metadata requires geometry: " + str(instance))
                available.add((kind.name, category.name, int(instance.name)))
    for row in declaration["layouts"]:
        layout = json.loads(_file(root, row["path"]).read_text())
        _require(type(layout) is dict, "Native layouts must be mappings")
        labels = set()
        for kind, categories in layout.items():
            if kind in ("Room", "Table", "Ground", "Light", "Background"):
                continue
            _require(kind in OBJECT_TYPES and type(categories) is dict, "Unknown native layout object type: " + kind)
            for category, instances in categories.items():
                _require(_component(category) and type(instances) is list, "Invalid native layout category")
                for instance in instances:
                    _require(type(instance) is dict, "Native layout instances must be mappings")
                    index = instance.get("category_idx")
                    _require(type(index) is int and index >= 0 and (kind, category, index) in available,
                             "Native layout refers to a missing asset: " + str((kind, category, index)))
                    _require(instance.get("category", category) == category,
                             "Native layout category differs from its resource directory")
                    physics = instance.get("physics", {})
                    _require(type(physics) is dict and physics.get("type", "rigid") == kind.lower(),
                             "Native layout physics type differs from its native object type")
                    label = instance.get("label")
                    _require(isinstance(label, str) and label and label not in labels,
                             "Native layout labels must be nonempty and unique")
                    labels.add(label)


def check_source(bundle, *, built=False):
    """Validate a native declaration without importing authored or simulator code.

    Unbuilt sources may lack generated assets and layouts. The built check used
    by export additionally verifies native resource resolution for every layout.
    Python validation checks syntax and the exact registered class name only;
    native inheritance and lifecycle behavior need runtime integration evidence.
    """
    root = _directory(bundle)
    declaration = json.loads(_file(root, DECLARATION).read_text())
    _require(type(declaration) is dict and DECLARATION_KEYS <= set(declaration)
             and set(declaration) <= DECLARATION_KEYS | {"data_files"}
             and type(declaration["schema_version"]) is int and declaration["schema_version"] == 1,
             "Unsupported native task declaration")
    task_id = declaration["task_id"]
    _require(isinstance(task_id, str) and re.fullmatch(r"[a-z][a-z0-9_]*", task_id)
             and not keyword.iskeyword(task_id), "Native task ID must be a lowercase Python class identifier")
    _require(declaration["task_module"] == "task.py" and declaration["task_config"] == "task_config.yaml",
             "Native source uses task.py and task_config.yaml")
    asset_root = _relative(declaration["asset_root"])
    _require(asset_root.parts[0] not in ("python", "task.py", "task_config.yaml", DECLARATION),
             "Native asset root must not overlap task source files")
    helpers = declaration["python_files"]
    _require(type(helpers) is list and all(isinstance(name, str) for name in helpers)
             and len(helpers) == len(set(helpers)), "Declare distinct Python helper files")
    for name in helpers:
        path = _relative(name)
        _require(path.suffix == ".py" and path.parts[0] not in ("task", "env", "src", "utils", "benchmark42")
                 and name != "task.py", "Python helpers must use a task-owned namespace: " + name)
        ast.parse(_file(root, name).read_bytes(), filename=name)
    data = declaration.get("data_files", [])
    _require(type(data) is list and all(isinstance(name, str) for name in data)
             and len(data) == len(set(data)), "Declare distinct native JSON data files")
    for name in data:
        path = _relative(name)
        _require(path.suffix == ".json" and name != DECLARATION
                 and not path.is_relative_to(asset_root)
                 and name not in {row["path"] for row in declaration["layouts"]},
                 "Native JSON data must not overlap declaration, assets or layouts: " + name)
        json.loads(_file(root, name).read_text())
    tree = ast.parse(_file(root, declaration["task_module"]).read_bytes(), filename="task.py")
    _require(sum(isinstance(node, ast.ClassDef) and node.name == task_id for node in tree.body) == 1,
             "task.py must declare exactly one top-level class named " + task_id)
    _file(root, declaration["task_config"])
    config = declaration["native_config"]
    _require(type(config) is dict and set(config) == {"scene", "robot", "camera", "simulation"}
             and all(_component(config[key]) for key in ("scene", "robot", "camera"))
             and type(config["simulation"]) is dict, "Invalid native task configuration")
    simulation = config["simulation"]
    _require(type(simulation.get("dt")) in (int, float) and math.isfinite(simulation["dt"])
             and simulation["dt"] > 0 and type(simulation.get("decimation")) is int
             and simulation["decimation"] > 0, "Native simulation requires positive dt and decimation")
    _require(_component(declaration["config_name"]) and type(declaration["eval_seed"]) is int,
             "Invalid native evaluation resource configuration")
    _require(type(declaration["max_control_steps"]) is int and declaration["max_control_steps"] > 0
             and type(declaration["control_dt"]) in (int, float) and math.isfinite(declaration["control_dt"])
             and declaration["control_dt"] > 0, "Native control budget and interval must be positive")
    _require(declaration["finish_mode"] in ("home", "hold"), "Declare the executor finish hint as home or hold")
    layouts = declaration["layouts"]
    _require(type(layouts) is list and layouts, "Native source requires declared layouts")
    seeds, paths = set(), set()
    for index, row in enumerate(layouts):
        _require(type(row) is dict and set(row) == {"layout_id", "seed", "path"}
                 and type(row["layout_id"]) is int and row["layout_id"] == index
                 and type(row["seed"]) is int and row["seed"] not in seeds,
                 "Native layout IDs must be contiguous with distinct authored seeds")
        path = _relative(row["path"])
        _require(path.suffix == ".json" and row["path"] not in paths
                 and not path.is_relative_to(asset_root) and row["path"] != DECLARATION,
                 "Declare distinct native layout JSON paths outside the asset root")
        seeds.add(row["seed"])
        paths.add(row["path"])
    for name in _source_files(root, declaration, built=built):
        _file(root, name)
    if built:
        _check_layouts(root, declaration)
    # Reject non-JSON values such as NaN even in vendor configuration fields.
    json.dumps(declaration, allow_nan=False)
    return declaration


def _bindings(declaration):
    """Describe the authored files exposed through native runtime paths."""
    return {
        "task_id": declaration["task_id"],
        "bundle": "bundle",
        "task_module": "python/task/RoboDojo/tasks/" + declaration["task_id"] + ".py",
        "task_config": "bundle/" + declaration["task_config"],
        "asset_root": "bundle/" + declaration["asset_root"],
        "python_files": ["python/" + name for name in declaration["python_files"]],
        "layouts": [{**row, "path": "bundle/" + row["path"]} for row in declaration["layouts"]],
        **{key: deepcopy(declaration[key]) for key in (
            "native_config", "config_name", "eval_seed", "max_control_steps", "control_dt", "finish_mode",
        )},
    }


def _bytecode_cache(relative, files):
    path = Path(relative)
    if len(path.parts) < 3 or path.parts[0] != "python" or path.parent.name != "__pycache__":
        return False
    match = re.fullmatch(r"(.+)\.cpython-\d+(?:\.opt-[12])?\.pyc", path.name)
    return bool(match and (path.parent.parent / (match[1] + ".py")).as_posix() in files)


def verify_package(package):
    """Verify the complete immutable inventory and native resource bindings."""
    package = _directory(package)
    manifest = json.loads(_file(package, MANIFEST).read_text())
    _require(type(manifest) is dict and type(manifest.get("schema_version")) is int
             and manifest["schema_version"] == 2 and manifest.get("native_protocol") == PROTOCOL
             and manifest.get("identity_sha256") == _identity(manifest), "Unsupported or changed native task manifest")
    files = manifest.get("files")
    _require(type(files) is dict and files and MANIFEST not in files, "Native package requires a bound file inventory")
    for name, record in files.items():
        path = _file(package, name)
        _require(type(record) is dict and set(record) == {"sha256", "bytes"}
                 and type(record["bytes"]) is int and record["bytes"] == path.stat().st_size
                 and record["sha256"] == digest(path), "Native task package file changed: " + name)
    actual = set()
    for path in package.rglob("*"):
        _require(not path.is_symlink(), "Native package cannot contain aliased files or directories")
        if path.is_file():
            relative = path.relative_to(package).as_posix()
            if not _bytecode_cache(relative, files):
                actual.add(relative)
        else:
            _require(path.is_dir(), "Unsupported native package filesystem entry")
    _require(actual == set(files) | {MANIFEST}, "Native package contains missing or unbound files")
    declaration = check_source(package / "bundle", built=True)
    bindings = _bindings(declaration)
    _require(all(manifest.get(key) == value for key, value in bindings.items()),
             "Native manifest differs from the authored declaration")
    expected = {"bundle/" + name for name in _source_files(package / "bundle", declaration, built=True)}
    expected.update({RUNTIME, "python/benchmark42/__init__.py", "python/benchmark42/native_tasks/__init__.py",
                     bindings["task_module"], *bindings["python_files"]})
    _require(set(files) == expected, "Native package includes undeclared runtime inputs")
    copies = {bindings["task_module"]: "bundle/" + declaration["task_module"]}
    copies.update({"python/" + name: "bundle/" + name for name in declaration["python_files"]})
    for destination, source in copies.items():
        _require(files[destination] == files[source], "Native task module or helper differs from its authored source")
    _require(type(manifest.get("source")) is dict
             and manifest["source"].get("declaration_sha256") == files["bundle/" + DECLARATION]["sha256"],
             "Native package source identity differs")
    return manifest


def export_task(bundle, output, *, seeds=None, task_id=None, finish_mode=None):
    """Export the declared native class and resources unchanged to a fresh package.

    Optional legacy CLI selectors must agree with the declaration. Revising a
    task identity, layout inventory or executor hint belongs in the source.
    """
    bundle = _directory(bundle)
    output = _destination(output, (bundle,))
    declaration = check_source(bundle, built=True)
    for given, expected, name in (
        (seeds, [row["seed"] for row in declaration["layouts"]], "seeds"),
        (task_id, declaration["task_id"], "task ID"),
        (finish_mode, declaration["finish_mode"], "finish hint"),
    ):
        _require(given is None or given == expected, "Export " + name + " must match native_task.json")
    bindings = _bindings(declaration)
    copies = {"bundle/" + name: bundle / name for name in _source_files(bundle, declaration, built=True)}
    copies[bindings["task_module"]] = bundle / declaration["task_module"]
    copies.update({"python/" + name: bundle / name for name in declaration["python_files"]})
    copies[RUNTIME] = Path(__file__).resolve()
    output.mkdir(parents=True)
    for destination, source in copies.items():
        target = output / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    for name in ("python/benchmark42/__init__.py", "python/benchmark42/native_tasks/__init__.py"):
        (output / name).write_text('"""Self-contained native task package tools."""\n')
    files = {path.relative_to(output).as_posix(): {"sha256": digest(path), "bytes": path.stat().st_size}
             for path in sorted(output.rglob("*")) if path.is_file()}
    manifest = {
        "schema_version": 2,
        "native_protocol": PROTOCOL,
        **bindings,
        "files": files,
        "source": {"bundle": str(bundle), "declaration_sha256": digest(bundle / DECLARATION)},
    }
    manifest["identity_sha256"] = _identity(manifest)
    write_json(output / MANIFEST, manifest)
    return verify_package(output)


def materialize(package, robodojo_root, assets_root, output):
    """Bind native resources in an isolated root, without editing the dependency."""
    package, native, assets = (_directory(value) for value in (package, robodojo_root, assets_root))
    output = _destination(output, (package, native, assets))
    manifest = verify_package(package)
    global_config = _file(native, "env/global_configs.py")
    registry = _file(native, "task/RoboDojo/task_registry.py")
    output.mkdir(parents=True)
    for name in ("utils", "src", "client_server", "env_cfg", "XPolicyLab", "IsaacLab", "curobo"):
        source = native / name
        if source.exists():
            (output / name).symlink_to(source, target_is_directory=source.is_dir())
    (output / "env").mkdir()
    for source in (native / "env").iterdir():
        if source.name == "__pycache__":
            continue
        target = output / "env" / source.name
        if source.name == "global_configs.py":
            shutil.copyfile(source, target)
        else:
            target.symlink_to(source, target_is_directory=source.is_dir())
    task_root = output / "task/RoboDojo"
    (task_root / "tasks").mkdir(parents=True)
    (task_root / "config").mkdir()
    (task_root / "task_registry.py").symlink_to(registry)
    task_id = manifest["task_id"]
    (task_root / "tasks" / (task_id + ".py")).symlink_to(package / manifest["task_module"])
    task_config = task_root / "config" / (task_id + ".yml")
    shutil.copyfile(package / manifest["task_config"], task_config)
    task_defaults = {"scene_config": manifest["native_config"]["scene"],
                     "robot_config": manifest["native_config"]["robot"],
                     "camera_config": manifest["native_config"]["camera"],
                     "eval_nums": len(manifest["layouts"])}
    if "render_interval" in manifest["native_config"]["simulation"]:
        task_defaults["render_interval"] = manifest["native_config"]["simulation"]["render_interval"]
    write_json(task_root / "config/_task.yml", {"tasks": {task_id: task_defaults}})
    (output / "Assets").mkdir()
    for name in BASE_ASSETS:
        source = assets / name
        if source.exists():
            (output / "Assets" / name).symlink_to(source, target_is_directory=source.is_dir())
    object_root = output / "Assets/Object/RoboDojo"
    object_root.mkdir(parents=True)
    for source in (package / manifest["asset_root"]).iterdir():
        (object_root / source.name).symlink_to(source, target_is_directory=True)
    layouts = []
    for row in manifest["layouts"]:
        relative = (Path("Assets/Eval_Layout/RoboDojo") / manifest["config_name"] / str(manifest["eval_seed"])
                    / f"{task_id}_{row['layout_id']}.json")
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(package / row["path"], destination)
        layouts.append({**row, "native_path": relative.as_posix(), "sha256": digest(destination)})
    receipt = {
        "schema_version": 2,
        "native_protocol": PROTOCOL,
        "package": str(package),
        "identity_sha256": manifest["identity_sha256"],
        "native_root": str(output),
        "python_path": [str(package / "python"), str(output), str(output / "XPolicyLab")],
        "task_config": str(task_config),
        "task_id": task_id,
        "config_name": manifest["config_name"],
        "eval_seed": manifest["eval_seed"],
        "layouts": layouts,
        "source_root": str(native),
        "assets_root": str(assets),
        "global_config_sha256": digest(global_config),
        "task_registry_sha256": digest(registry),
        "native_config": manifest["native_config"],
        "runtime_requirements": {
            "bytecode_writes": False,
            "simulator": "Use the existing native simulator and dependencies; no installation is performed",
            "source_bindings": "General source and baseline assets are live dependencies, not immutable copies",
        },
        "scope": "Native namespace and resource binding; simulator and task-success qualification remain separate",
    }
    write_json(output / "native_installation.json", receipt)
    return receipt
